package com.bignerdranch.android.bookpage.bookpagefragment;

import android.arch.lifecycle.ViewModel;

public class BookPageLendingLogViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
