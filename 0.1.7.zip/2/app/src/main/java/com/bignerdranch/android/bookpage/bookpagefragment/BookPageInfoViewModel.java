package com.bignerdranch.android.bookpage.bookpagefragment;

import android.arch.lifecycle.ViewModel;

public class BookPageInfoViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
