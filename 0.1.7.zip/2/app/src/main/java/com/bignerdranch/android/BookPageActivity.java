package com.bignerdranch.android;

import android.support.v4.app.Fragment;

import com.bignerdranch.android.bookpage.BookPageFragment;

public class BookPageActivity extends SingleFragmentActivity{

    @Override
    protected Fragment createFragment() {
        //關閉案兩次退出
        super.setOneMoreTimeExit(false);
        return BookPageFragment.newInstance();
    }

}
