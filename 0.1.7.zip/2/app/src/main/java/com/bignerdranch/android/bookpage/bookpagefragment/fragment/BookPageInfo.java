package com.bignerdranch.android.bookpage.bookpagefragment.fragment;

import android.arch.lifecycle.ViewModelProviders;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.bignerdranch.android.R;
import com.bignerdranch.android.bookpage.bookpagefragment.BookPageInfoViewModel;

public class BookPageInfo extends Fragment {

    private BookPageInfoViewModel mViewModel;
    private RecyclerView mRecyclerView;

    public static BookPageInfo newInstance() {
        return new BookPageInfo();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.book_page_info_fragment, container, false);
        mRecyclerView = (RecyclerView)v.findViewById(R.id.book_page_info_fragment_recyclerview);
        return v;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mViewModel = ViewModelProviders.of(this).get(BookPageInfoViewModel.class);
        // TODO: Use the ViewModel
    }
    private class BookHolderAdapter extends RecyclerView.Adapter<BookHolder> {

        @Override
        public int getItemViewType(int position) {
            return super.getItemViewType(position);
        }

        @NonNull
        @Override
        public BookHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
            return null;
        }

        @Override
        public void onBindViewHolder(@NonNull BookHolder bookHolder, int i) {
        }

        @Override
        public int getItemCount() {
            return 0;
        }
    }

    private class BookHolder extends RecyclerView.ViewHolder {
        public BookHolder(@NonNull View itemView) {
            super(itemView);
        }
    }

}
