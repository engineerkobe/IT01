package com.bignerdranch.android.bookpage;

import android.arch.lifecycle.ViewModelProviders;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.bignerdranch.android.R;
import com.bignerdranch.android.bean.BookPageViewModel;
import com.bignerdranch.android.bookpage.bookpagefragment.BookPagerFragmetntLab;

import java.util.ArrayList;

public class BookPageFragment extends Fragment {

    private BookPageViewModel mViewModel;

    private ViewPager mViewPager;
    private TabLayout mTabLayout;
    private ArrayList<Fragment> fragments = new ArrayList<>();

    private String[] mTabTitles = new String[]{"最新","热门","我的"};
    private BookPagerFragmetntLab mBookPagerFragmetntLab;

    public static BookPageFragment newInstance() {
        return new BookPageFragment();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.book_page_status_bar, container, false);

        mBookPagerFragmetntLab = BookPagerFragmetntLab.get(getChildFragmentManager());
        mViewPager = (ViewPager) v.findViewById(R.id.book_page_viewpager);
        mTabLayout = (TabLayout) v.findViewById(R.id.book_page_tablayout);
        //設置title
        for(String tmp: mTabTitles)
            mTabLayout.addTab((mTabLayout.newTab()).setText(tmp));

        mViewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(mTabLayout));
        mTabLayout.addOnTabSelectedListener(new TabLayout.ViewPagerOnTabSelectedListener(mViewPager));

        mViewPager.setAdapter(mBookPagerFragmetntLab.getBookPagerFragmentAdapter(getChildFragmentManager()));

        return v;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mViewModel = ViewModelProviders.of(this).get(BookPageViewModel.class);
        // TODO: Use the ViewModel
    }

}
