package com.bignerdranch.android.bookpage.bookpagefragment;

import android.arch.lifecycle.ViewModel;

public class BookPageReviewsViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
