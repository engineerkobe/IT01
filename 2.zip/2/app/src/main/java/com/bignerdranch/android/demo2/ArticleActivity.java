package com.bignerdranch.android.demo2;

import android.arch.lifecycle.ViewModelProvider;
import android.content.Context;
import android.content.Intent;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.bignerdranch.android.R;
import com.bignerdranch.android.SingleFragmentActivity;

public class ArticleActivity extends SingleFragmentActivity{
    private static final String POSTER = "ArticleActivity.poster";

    public static Intent newIntent(Context context, Article article) {
        Intent intent = new Intent(context,ArticleActivity.class);
        intent.putExtra(POSTER,String.valueOf(article.getRootid()));
        return intent;
    }

    public static String getRootid(Intent intent) {
       return intent.getStringExtra(POSTER);
    }
    @Override
    protected Fragment createFragment() {
        return ArticleFragment.newInstance();
    }
}
