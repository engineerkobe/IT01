package com.bignerdranch.android.bean;

import java.util.Date;

public class RFIDBook {
    private String mRFID;
    private boolean mIsBorrow ;
    private String mBorrow;
    private Date mDate;
    private String mISBN;

}
