package com.bignerdranch.android.config;

import java.io.File;

public class MyUser {
    private static String sAccount;
    private static String sPassword;
    private static String sName;
    //頭貼檔案
    private static File sStickerFile;

    public static String getAccount() {
        return sAccount;
    }

    public static void setAccount(String account) {
        sAccount = account;
    }

    public static String getPassword() {
        return sPassword;
    }

    public static void setPassword(String password) {
        sPassword = password;
    }

    public static String getName() {
        return sName;
    }

    public static void setName(String name) {
        sName = name;
    }

    public static File getStickerFile() {
        return sStickerFile;
    }

    public static void setStickerFile(File stickerFile) {
        sStickerFile = stickerFile;
    }

}
