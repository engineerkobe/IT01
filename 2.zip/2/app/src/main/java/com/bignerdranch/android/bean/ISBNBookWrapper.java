package com.bignerdranch.android.bean;

import android.database.Cursor;
import android.database.CursorWrapper;

import com.bignerdranch.android.basehelper.BookDbSchema;

public class ISBNBookWrapper extends CursorWrapper {
    /**
     * Creates a cursor wrapper.
     *
     * @param cursor The underlying cursor to wrap.
     */
    public ISBNBookWrapper(Cursor cursor) {
        super(cursor);
    }

    public Book getBook() {
        String name = getString(getColumnIndex(BookDbSchema.ISBNBook.Cols.NAME));
        String isbn = getString(getColumnIndex(BookDbSchema.ISBNBook.Cols.ISBN));
        String content = getString(getColumnIndex(BookDbSchema.ISBNBook.Cols.CONTENT));
        int count = getInt(getColumnIndex(BookDbSchema.ISBNBook.Cols.COUNT));

        Book book = new Book();
        book.setName( name);
        book.setISBN(isbn);
        book.setContent(content);
        book.setCount(count);

        return book;
    }
}
