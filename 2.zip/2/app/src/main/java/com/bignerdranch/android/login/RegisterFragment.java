package com.bignerdranch.android.login;

import android.arch.lifecycle.ViewModelProvider;
import android.os.AsyncTask;
import android.os.Bundle;
import android.renderscript.ScriptGroup;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.bignerdranch.android.R;
import com.bignerdranch.android.config.MyServer;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

public class RegisterFragment extends Fragment {
    private EditText mPasswordEditText;
    private EditText mAccountEditText;
    private Button mRegiesterButton;

    public static RegisterFragment newInstance() {
        
        Bundle args = new Bundle();
        
        RegisterFragment fragment = new RegisterFragment();
        fragment.setArguments(args);
        return fragment;
    }
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.book_login_main_register,container,false);
        mAccountEditText = (EditText) v.findViewById(R.id.book_login_main_register_account);
        mPasswordEditText = (EditText) v.findViewById(R.id.book_login_main_register_password);
        mRegiesterButton = (Button) v.findViewById(R.id.book_login_main_register_button);
        mRegiesterButton.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                new ReiesterTask().execute();
            }
        });
        return v;
    }
    class ReiesterTask extends AsyncTask<String,Void,String> {
        String mURL = MyServer.JOIN_ACCOUNT_URL;
        String mAccount = mAccountEditText.getText().toString();
        String mPassword = mPasswordEditText.getText().toString();

        @Override
        protected String doInBackground(String... strings) {
            URL url = null;
            String result = "";
            String data = "account="+ mAccount +"&" + "password=" + mPassword;
            try {
                url = new URL(mURL);
                URLConnection  urlC = url.openConnection();
                urlC.setDoOutput(true);
                urlC.setDoInput(true);
                OutputStream os = urlC.getOutputStream();
                os.write(data.getBytes("UTF-8"));
                os.flush();

                InputStream is = urlC.getInputStream();
                byte bys[] = new byte[1024];
                for(int tmp; (tmp = is.read(bys)) != -1; )
                   result+=new String(bys);


            } catch (IOException e) {
                e.printStackTrace();
            }

            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            Toast.makeText(getContext(),s,Toast.LENGTH_SHORT).show();
        }
    }
}
