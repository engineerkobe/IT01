package com.bignerdranch.android;

import android.app.ActionBar;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends SingleFragmentActivity {
    @Override
    protected Fragment createFragment() {
        //開啟在案一次就退出
        super.setOneMoreTimeExit(true);
        return new MainFragment();
    }


}
