package com.bignerdranch.android;

import android.app.PendingIntent;
import android.content.Intent;
import android.nfc.NfcAdapter;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.widget.Toast;

import com.bignerdranch.android.bean.Book;
import com.bignerdranch.android.bean.RFID;
import com.bignerdranch.android.config.MyServer;
import com.bignerdranch.android.util.JSONObjectToBean;
import com.bignerdranch.android.util.SingleLoginTask;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import static com.bignerdranch.android.util.JSONObjectToBean.JSONObjectToBook;
import static com.bignerdranch.android.util.JSONObjectToBean.JSONObjectToRFID;

public class MainActivity extends SingleFragmentActivity {
    private NfcAdapter nfcAdapter;
    private PendingIntent mPendingIntent;
    private String TAG = "MainActivity";

    @Override
    public void onCreate(Bundle savedInstanceState ) {
        super.onCreate(savedInstanceState );
        nfcAdapter = NfcAdapter.getDefaultAdapter(this);
        mPendingIntent = PendingIntent.getActivity(this,0,
            new Intent(this,getClass()).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),0);

    }

    @Override
    protected void onResume() {
        super.onResume();
        nfcAdapter.enableForegroundDispatch(this,mPendingIntent,null,null);
    }

    @Override
    protected void onPause() {
        super.onPause();
        if(nfcAdapter!=null) {
            nfcAdapter.disableForegroundDispatch(this);
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
//        super.onNewIntent(intent);
        if(intent.getAction().equals(NfcAdapter.ACTION_TAG_DISCOVERED)) {
            String tmp = ByteArrayToHexString(intent.getByteArrayExtra(NfcAdapter.EXTRA_ID)) ;
//            Log.d(TAG,tmp );
            new RFIDservices(MyServer.GET_BOOK_FOR_RFID_URL,tmp).execute();
            Toast.makeText(this,tmp  , Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected Fragment createFragment() {
//        UserLab.get(this).deleteTableValues();
        //開啟在案一次就退出
        super.setOneMoreTimeExit(true);
        return new MainFragment();

    }

    private String ByteArrayToHexString(byte[] inarray) {
        int i, j, in;
        String[] hex = { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A",
                "B", "C", "D", "E", "F" };
        String out = "";
        for (j = 0; j < inarray.length; ++j) {
            in = (int) inarray[j] & 0xff;
            i = (in >> 4) & 0x0f;
            out += hex[i];
            i = in & 0x0f;
            out += hex[i];
        }
        return out;
    }
    private class RFIDservices extends SingleLoginTask {


        public RFIDservices(String function, String RFID) {
            super(String.format(function,RFID));
        }

        @Override
        protected void onPostExecute(String s) {
            if(s.equals("Can't find")) {
                Toast.makeText(MainActivity.this,s,Toast.LENGTH_SHORT).show();
                return;
            }
            try {
                JSONObject json = new JSONObject(s);
                Log.d(TAG,json.toString());
                Book book = JSONObjectToBook(json);
                RFID rfid = JSONObjectToRFID(json);
                Date date = new Date(json.getLong("servertime"));
                startActivity(BookPageActivity.newInstance(MainActivity.this,book,rfid,date));
//                mBooks.add(book);
            } catch (JSONException e1) {
                e1.printStackTrace();
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }
    }
}
