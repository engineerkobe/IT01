package com.bignerdranch.android.bean;

public class ISBNBook {

    private String mISBN;
    private String mName;
    private String mContent;
    private int mCount;
}
