package com.bignerdranch.android.bookpage.bookpagefragment.model;

import java.util.Date;

public class Book {

    private String mTitle;
    private String mName;
    private String mISBN;
    private String mID;

    //內容
    private String mContent;
    //簡介
    private String mIntroduction;
    //所在書櫃
    private int mBookNumber;
    private int mCount;
    private byte [] mImage;
    private Date mDate;
}
