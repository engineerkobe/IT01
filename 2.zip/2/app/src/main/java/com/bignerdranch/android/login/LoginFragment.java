package com.bignerdranch.android.login;

import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import com.bignerdranch.android.config.MyServer;
import com.bignerdranch.android.R;
import com.bignerdranch.android.login.bean.User;
import com.bignerdranch.android.util.SingleLoginTask;


public class LoginFragment extends Fragment {
    private EditText mAccountEdit;
    private EditText mPasswordEdit;
    private Button mLoginButton;
    private CheckBox mAutoLoginCheckBox;
    private static final String TAG = "LoginFragment";
    Handler mhandler;
    public static LoginFragment newInstance() {
        Bundle args = new Bundle();
        LoginFragment fragment = new LoginFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mhandler = new Handler();
        mhandler.getLooper();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.book_login_main,container,false);
        User user = UserLab.get(getActivity()).getLoginData();
        init(v);
        if(user!=null) {
            mAccountEdit.setText(user.getAccount());
            mPasswordEdit.setText(user.getPassword());
        }
        return v;
    }

    private void init(View v) {
        mAccountEdit = (EditText) v.findViewById(R.id.book_login_main_account);
        mPasswordEdit = (EditText)v.findViewById(R.id.book_login_main_password);
        mLoginButton = (Button)v.findViewById(R.id.book_login_main_login_button);
        mAutoLoginCheckBox = (CheckBox)v.findViewById(R.id.book_login_main_auto_login);
        mAutoLoginCheckBox.setChecked(true);
        mLoginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String account = mAccountEdit.getText().toString();
                String password = mPasswordEdit.getText().toString();
                if(account.matches("[a-zA-Z0-9]+")
                    && password.matches("[a-zA-Z0-9]+")) {
                    MyServer.get(getContext(),account,password);
                    Log.d(TAG,MyServer.LOGIN_URL);
                    new LoginTask(MyServer.LOGIN_URL).execute();
                }
                else
                    Log.d(TAG,"請認真輸入帳號密碼");
            }

        });

    }

    void saveAccount() {
        if (mAutoLoginCheckBox.isChecked()) {
            Log.d(TAG, "自動登入open");
            UserLab.get(getActivity()).saveLoginData(MyServer.mAccount,MyServer.mPassword );
        }
    }
    //登入時調用
    private class LoginTask extends SingleLoginTask {

        public LoginTask( String function) {
            super(function);
        }

        @Override
        protected void onPostExecute(String loginstatus) {
            super.onPostExecute(loginstatus);
            if(loginstatus.equals("login success")) {
                Toast.makeText(getContext(),R.string.ok,Toast.LENGTH_SHORT).show();
                Log.d(TAG, "登入成功");
                saveAccount();
                getActivity().finish();
            }
            else {
                Toast.makeText(getContext(), R.string.login_incorrect, Toast.LENGTH_SHORT).show();
                Log.d(TAG, "登入失敗");
            }
        }
    }
}
