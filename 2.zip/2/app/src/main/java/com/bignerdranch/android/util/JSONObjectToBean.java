package com.bignerdranch.android.util;

import com.bignerdranch.android.bean.Book;
import com.bignerdranch.android.bean.RFID;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class JSONObjectToBean {
    public static Book JSONObjectToBook(JSONObject json) throws JSONException {
        String isbn = json.getString("isbn");
        String name = json.getString("name");
        String content = json.getString("content");
        int count = json.getInt("count");

        Book book = new Book();
        book.setISBN(isbn);
        book.setContent(content);
        book.setName(name);
        book.setTitle(name);
        book.setCount(count);
        return book;
    }
    public static RFID JSONObjectToRFID(JSONObject json) throws JSONException, ParseException {

        String borrower = json.getString("borrower");
        boolean isBorrow = json.getBoolean("is_borrow");
        String date =  json.getString("log") ;
        String rfidid = json.getString("rfid");
        String book_case_name = json.getString("book_case_name");
        Date log = new SimpleDateFormat("yyyy-MM-dd").parse(date);
        String isbn = json.getString("isbn");

        RFID rfid = new RFID();
        rfid.setBookCaseName(book_case_name);
        rfid.setBorrow(isBorrow);
        rfid.setLog(log);
        rfid.setBorrower(borrower);
        rfid.setIsbn(isbn);
        rfid.setRfid(rfidid);

        return rfid;
    }
}

/*
    JSONObject json = new JSONObject(s);
                Log.d(TAG,json.toString());


                        startActivity(BookPageActivity.newInstance(MainActivity.this,book,rfid));
                        */
