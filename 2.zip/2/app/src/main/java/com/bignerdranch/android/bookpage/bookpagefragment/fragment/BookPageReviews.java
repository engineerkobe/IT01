package com.bignerdranch.android.bookpage.bookpagefragment.fragment;

import android.arch.lifecycle.ViewModelProviders;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.bignerdranch.android.R;


public class BookPageReviews extends Fragment {

    private RecyclerView mRecyclerView;

    public static BookPageReviews newInstance() {
        return new BookPageReviews();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.book_page_reviews_fragment, container, false);
        mRecyclerView = (RecyclerView)v.findViewById(R.id.book_page_reviews_fragment_revyclerview);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        mRecyclerView.setAdapter(new ReviewsAdapter(inflater));
        return v;
    }



    private class ReviewsAdapter extends RecyclerView.Adapter<ReviewsHolder> {
        LayoutInflater mInflater;
        public ReviewsAdapter(LayoutInflater inflater) {
            mInflater = inflater ;
        }
        @NonNull
        @Override
        public ReviewsHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
            return new ReviewsHolder(mInflater,viewGroup);
        }

        @Override
        public void onBindViewHolder(@NonNull ReviewsHolder reviewsHolder, int i) {

        }

        @Override
        public int getItemCount() {
            return 20;
        }
    }

    private class ReviewsHolder extends RecyclerView.ViewHolder {

        public ReviewsHolder(LayoutInflater inflater,ViewGroup viewGroup) {
            super(inflater.inflate(R.layout.main_account_list_item,viewGroup,false));
//            itemView
        }
    }
}
