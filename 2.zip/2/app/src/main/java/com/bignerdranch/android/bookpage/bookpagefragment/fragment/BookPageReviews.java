package com.bignerdranch.android.bookpage.bookpagefragment.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.bignerdranch.android.BookPageActivity;
import com.bignerdranch.android.R;
import com.bignerdranch.android.bean.Book;
import com.bignerdranch.android.bean.RFID;
import com.bignerdranch.android.config.MyServer;
import com.bignerdranch.android.util.JSONObjectToBean;
import com.bignerdranch.android.util.SingleLoginTask;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;


public class BookPageReviews extends Fragment {

    private RecyclerView mRecyclerView;
    private ArrayList<String> mBookCaseNames;
    private Book mBook;
    private RFID mRFID;
    private Date mDate;
    private ReviewsAdapter mRecyclerAdapter;

    public static BookPageReviews newInstance() {
        return new BookPageReviews();
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mBookCaseNames = new ArrayList<>();
        Intent intent = getActivity().getIntent();
        mBook = BookPageActivity.getBook(intent);
        mRFID = BookPageActivity.getRFID(intent);
        mDate = BookPageActivity.getServerDate(intent);

        new DemoAsyncTack(String.format(MyServer.GET_RFID_LIST_URL,mBook.getISBN())).execute();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.book_page_reviews_fragment, container, false);
        mRecyclerView = (RecyclerView)v.findViewById(R.id.book_page_reviews_fragment_revyclerview);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        mRecyclerAdapter = new ReviewsAdapter(inflater);
        mRecyclerView.setAdapter(mRecyclerAdapter);

        return v;
    }



    private class ReviewsAdapter extends RecyclerView.Adapter<ReviewsHolder> {
        LayoutInflater mInflater;
        public ReviewsAdapter(LayoutInflater inflater) {
            mInflater = inflater ;
        }
        @NonNull
        @Override
        public ReviewsHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
            return new ReviewsHolder(mInflater,viewGroup);
        }

        @Override
        public void onBindViewHolder(@NonNull ReviewsHolder reviewsHolder, int i) {
            reviewsHolder.bind(mBookCaseNames.get(i));

        }

        @Override
        public int getItemCount() {
            return mBookCaseNames.size();
        }
    }

    private class ReviewsHolder extends RecyclerView.ViewHolder {
        private TextView mBookCaseTextView;
        public ReviewsHolder(LayoutInflater inflater,ViewGroup viewGroup) {
            super(inflater.inflate(R.layout.book_page_reviews_fragment_item,viewGroup,false));
            mBookCaseTextView = (TextView) itemView.findViewById(R.id.book_page_reviews_fragment_item_bookcase);
        }

        public void bind(String tmp) {
            mBookCaseTextView.setText(tmp);
        }
    }


    class DemoAsyncTack extends SingleLoginTask  {

        public DemoAsyncTack(String function) {
            super(function);
        }

        @Override
        protected void onPostExecute(String s) {
            try {
                JSONArray jsonArray = new JSONArray(s);
                for(int i = 0; i < jsonArray.length(); i++) {
                    JSONObject json = jsonArray.getJSONObject(i);
                    RFID rfid = JSONObjectToBean.JSONObjectToRFID(json);
                    mBookCaseNames.add(rfid.getBookCaseName());
                }
            } catch (JSONException e) {
                e.printStackTrace();
            } catch (ParseException e) {
                e.printStackTrace();
            }
           mRecyclerAdapter.notifyDataSetChanged();
        }
    }
}
