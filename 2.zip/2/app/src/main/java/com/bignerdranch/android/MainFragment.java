package com.bignerdranch.android;

import android.app.ActionBar;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioGroup;

import com.bignerdranch.android.config.MyServer;
import com.bignerdranch.android.demo.Demo;
import com.bignerdranch.android.demo2.Demo2;
import com.bignerdranch.android.demo3.Demo3;
import com.bignerdranch.android.demo4.Demo4;


public class MainFragment extends Fragment {
    private ActionBar mActionBar;
    private RadioGroup mMainRadioGroup;
    private FragmentManager mFragmentManager;
    private static final String MAINRADIOGROUP = "MAINRADIOGROUP";
    private Demo mHomeFragment;
    private Demo2 mTalkFragment;
    private Demo3 mNotImplementFragment;
    private Demo4 mAccountFragment;


    public static MainFragment newInstance(String param1, String param2) {
        MainFragment fragment = new MainFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.activity_main,container,false);

        mMainRadioGroup = (RadioGroup) v.findViewById(R.id.main_menu_radiogroup);
        mMainRadioGroup.setOnCheckedChangeListener(mMenuOnchedChabgeListener);
//        mMainRadioGroup.set
        mFragmentManager =  getChildFragmentManager();
        Fragment fragment = mFragmentManager.findFragmentById(R.id.main_fragment_container);
        if(fragment == null) {
            fragment = new Demo();
            mFragmentManager.beginTransaction().add(R.id.main_fragment_container,fragment).commit();
        }
        checkLogin();
        return v;
    }

    /**
     * 檢查登入狀態
     */
    private void checkLogin() {
    }
    /**
     * radiogtoup 開關
     * @param b
     */
    public void radioGroupsetVisibility(boolean b) {
        if(!b)
            mMainRadioGroup.setVisibility(View.VISIBLE);
        else
            mMainRadioGroup.setVisibility(View.GONE);
    }



    /*
     *關閉ActionBar
     */
    private void closeActionBar() {
        getActivity().getActionBar().hide();
    }

    RadioGroup.OnCheckedChangeListener mMenuOnchedChabgeListener = new RadioGroup.OnCheckedChangeListener() {
        @Override
        public void onCheckedChanged(RadioGroup radioGroup, int i) {
            switch(i) {
                case R.id.main_menu_home:
                    Log.d(MAINRADIOGROUP,"home radio被點擊");
                    chanageHomeFragment();
                    //mFragmentManager.beginTransaction().replace(R.id.main_fragment_container,new Demo()).commit();
                    break;
                case R.id.main_menu_not_implement:
                    Log.d(MAINRADIOGROUP,"not implement被點擊");
                    break;
                case R.id.main_menu_borrow_book:
                    Log.d(MAINRADIOGROUP,"book radio被點擊");
                    if(MyServer.logingIsSuccess(getContext()) ==false)
                        startActivity( LoginFragmentActivity.newInstance(getContext()) );

                    if (MyServer.logingIsSuccess(getContext()) == false)
                        mMainRadioGroup.check(R.id.main_menu_home);
                    else
                        chanageBookFragment();
                    break;
                case R.id.main_menu_account:
                    Log.d(MAINRADIOGROUP,"account radio被點擊");
                    if(MyServer.logingIsSuccess(getContext()) ==false)
                        startActivity( LoginFragmentActivity.newInstance(getContext()) );

                    if (MyServer.logingIsSuccess(getContext()) == false)
                        mMainRadioGroup.check(R.id.main_menu_home);
                    else
                        changeAccountFragment();
                    break;
            }
        }

    };


    private void chanageHomeFragment() {
        FragmentTransaction fragmentTransaction = getChildFragmentManager().beginTransaction();
        if(mHomeFragment == null)
            mHomeFragment = new Demo();
        fragmentTransaction.replace(R.id.main_fragment_container,mHomeFragment).commit();
    }

    private void chanageTalkFragment() {
        FragmentTransaction fragmentTransaction = getChildFragmentManager().beginTransaction();
        if(mHomeFragment == null)
            mTalkFragment = new Demo2();
        fragmentTransaction.replace(R.id.main_fragment_container,mHomeFragment).commit();
    }

    private void chanageBookFragment() {
        FragmentTransaction fragmentTransaction = getChildFragmentManager().beginTransaction();
        if(mNotImplementFragment == null)
            mNotImplementFragment = new Demo3();
        fragmentTransaction.replace(R.id.main_fragment_container,mNotImplementFragment).commit();
    }

    private void changeAccountFragment() {
        FragmentTransaction fragmentTransaction = getChildFragmentManager().beginTransaction();
        if(mAccountFragment == null)
            mAccountFragment = new Demo4();
        fragmentTransaction.replace(R.id.main_fragment_container,mAccountFragment).commit();
    }


}
