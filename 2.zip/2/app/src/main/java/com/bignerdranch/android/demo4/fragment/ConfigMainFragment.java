package com.bignerdranch.android.demo4.fragment;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.bignerdranch.android.R;
import com.bignerdranch.android.demo4.AccountConfigActivity;
import com.bignerdranch.android.util.ImageUtil;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import static com.bignerdranch.android.util.ImageUtil.getImage;
import static com.bignerdranch.android.util.ImageUtil.saveImage;

public class ConfigMainFragment extends Fragment {

    private static final int GET_IMAGE_FOR_LOCAL = 1;
    private static final int CROP_IMAGE = 2;
    private static int  SET_NAME = 3;
    private static int SET_CONFIG = 4;

    private LinearLayout mHeadLinearLayout;
    private LinearLayout mNameLinearLayout;
    private ImageView mHeadImage;

    public static ConfigMainFragment newInstance() {

        Bundle args = new Bundle();

        ConfigMainFragment fragment = new ConfigMainFragment();
        fragment.setArguments(args);
        return fragment;
    }
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.main_account_config,container,false);
        mHeadLinearLayout = (LinearLayout) v.findViewById(R.id.main_account_config_head);
        mNameLinearLayout = (LinearLayout) v.findViewById(R.id.main_account_config_name);
        mHeadImage = (ImageView) v.findViewById(R.id.main_account_config_image);

        init();
        return v;
    }

    private void init() {
        mHeadLinearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent getImage = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(getImage, GET_IMAGE_FOR_LOCAL);
            }
        });
        mNameLinearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = AccountConfigActivity.setName(getContext());
                startActivity(intent);
            }
        });

        Bitmap bitmap = getImage(getContext(),"tmp.jpg");
        if(bitmap != null)
            mHeadImage.setImageBitmap(bitmap);
    }



    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(data == null)
            return;
        if(resultCode != Activity.RESULT_OK)
            return;
        switch (requestCode) {
            //從相簿取得相片
            case GET_IMAGE_FOR_LOCAL:
                Uri uri = data.getData();
//                Toast.makeText(getContext(),uri.getPath(),Toast.LENGTH_SHORT).show();
                Intent intent = ImageUtil.getImageForSystem(uri);
                //裁剪圖片
                startActivityForResult(intent,CROP_IMAGE);
                break;

            case CROP_IMAGE:
                //取得裁剪的圖片
                Bitmap bitmap = data.getExtras().getParcelable("data");
                if(bitmap != null ) {
                    saveImage(getActivity(),bitmap,"tmp.jpg");
                    //設置相片
                    mHeadImage.setImageBitmap(bitmap);
                }

                break;
        }
    }


}
