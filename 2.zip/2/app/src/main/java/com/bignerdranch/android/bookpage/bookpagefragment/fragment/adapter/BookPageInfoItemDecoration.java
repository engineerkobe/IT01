package com.bignerdranch.android.bookpage.bookpagefragment.fragment.adapter;

import android.annotation.SuppressLint;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.bignerdranch.android.R;

public class BookPageInfoItemDecoration extends RecyclerView.ItemDecoration {
    private Paint mGPaint;
    private int mOutRectHeight = 100;
    private Paint mPaint;

    @SuppressLint("ResourceAsColor")
    public BookPageInfoItemDecoration() {
//        super();
        mPaint = new Paint();
        mPaint.setColor(R.color.common_google_signin_btn_tint);
        mGPaint = new Paint();
        mGPaint.setColor(Color.GREEN);
        mGPaint.setTextSize(50);
    }

    @Override
    public void onDraw(@NonNull Canvas c, @NonNull RecyclerView parent, @NonNull RecyclerView.State state) {
//        c.drawColor(Color.BLACK);
        int childCount = parent.getChildCount();

        for ( int i = 0; i < childCount; i++ ) {
            View view = parent.getChildAt(i);
            int index = parent.getChildAdapterPosition(view);
            switch (index) {
                case 0:
                case 1:
                    onDrawTitle(c, view, parent);
                break;
                case 2:
                    onDrawSplitLine(c, view, parent);
                break;
                case 3:
                    onDrawTitle(c, view, parent);
                break;
                case 4:
                    onDrawSplitLine(c, view, parent);
                break;
                default:
                    continue;
            }
        }
    }

    private void onDrawSplitLine(Canvas c, View view, RecyclerView parent) {
        float dividerTop = view.getBottom();
        float dividerLeft = parent.getPaddingLeft();
        float dividerBottom = view.getBottom() + 1;
        float dividerRight = parent.getWidth() - parent.getPaddingRight();
        c.drawRect(dividerLeft, dividerTop, dividerRight, dividerBottom, mPaint);
//        c.drawText("TITLE",dividerLeft+mGPaint.getTextSize(),dividerBottom-mGPaint.getTextSize()/2,mGPaint);
    }

    private void onDrawTitle(Canvas c, View view, RecyclerView parent) {
        float dividerTop =  view.getBottom();
        float dividerLeft = parent.getPaddingLeft();
        float dividerBottom = view.getBottom() + mOutRectHeight;
        float dividerRight = parent.getWidth() - parent.getPaddingRight();
        c.drawRect(dividerLeft, dividerTop, dividerRight, dividerBottom, mPaint);
        c.drawText("TITLE",dividerLeft+mGPaint.getTextSize(),dividerBottom - mGPaint.getTextSize()/2,mGPaint);
    }


    @Override
    public void getItemOffsets(@NonNull Rect outRect, @NonNull View view, @NonNull RecyclerView parent, @NonNull RecyclerView.State state) {

        int childCount = parent.getChildCount();

        for ( int i = 0; i < childCount; i++ ) {
            int index = parent.getChildAdapterPosition(view);
            switch (index) {
                case 0:
                case 1:
                case 3:
                    outRect.bottom = mOutRectHeight;
                    break;
                case 2:
                case 4:
                    outRect.bottom = 1;
                    break;
                default:
                    continue;
            }
        }
    }
}
