package com.bignerdranch.android.demo.bean;

import java.util.Date;
import java.util.Objects;

public class Book {


    /**
     * +---------+--------------+------+-----+---------+-------+
     * | Field   | Type         | Null | Key | Default | Extra |
     * +---------+--------------+------+-----+---------+-------+
     * | isbn    | varchar(255) | NO   | PRI | NULL    |       |
     * | name    | varchar(255) | NO   |     | NULL    |       |
     * | content | text         | NO   |     | NULL    |       |
     * | count   | int(11)      | NO   |     | NULL    |       |
     * +---------+--------------+------+-----+---------+-------+
     *+----------------+--------------+------+-----+---------+-------+
     * | Field          | Type         | Null | Key | Default | Extra |
     * +----------------+--------------+------+-----+---------+-------+
     * | rfid           | varchar(255) | NO   | PRI | NULL    |       |
     * | is_borrow      | varchar(1)   | NO   |     | NULL    |       |
     * | borrower       | varchar(255) | NO   |     | NULL    |       |
     * | log            | datetime     | NO   |     | NULL    |       |
     * | isbn           | varchar(255) | NO   | MUL | NULL    |       |
     * | book_case_name | text         | YES  |     | NULL    |       |
     * +----------------+--------------+------+-----+---------+-------+
     */
    private String mRFID;
    //書的標題
    private String mTitle;
    //書的名字
    private String mName;
    //書的ISBN
    private String mISBN;
    //書的RFID
    private String mID;
    //內容
    private String mContent;
    //簡介
    private String mIntroduction;
    //所在書櫃
    private String mBooKCaseName;
    //有幾本書
    private int mCount;
    //mImagerUrl
    private String mImageUrl;
    private Date mDate;

    public String getTitle() {
        return mTitle;
    }

    public void setTitle(String title) {
        mTitle = title;
    }

    public String getName() {
        return mName;
    }

    public void setName(String name) {
        mName = name;
    }

    public String getISBN() {
        return mISBN;
    }

    public void setISBN(String ISBN) {
        mISBN = ISBN;
    }

    public String getID() {
        return mID;
    }

    public void setID(String ID) {
        mID = ID;
    }

    public String getContent() {
        return mContent;
    }

    public void setContent(String content) {
        mContent = content;
    }

    public String getIntroduction() {
        return mIntroduction;
    }

    public void setIntroduction(String introduction) {
        mIntroduction = introduction;
    }


    public int getCount() {
        return mCount;
    }

    public void setCount(int count) {
        mCount = count;
    }

    public String getImageUrl() {
        return mImageUrl;
    }

    public void setImageUrl(String imageUrl) {
        mImageUrl = imageUrl;
    }

    public Date getDate() {
        return mDate;
    }

    public void setDate(Date date) {
        mDate = date;
    }

    public String getBooKCaseName() {
        return mBooKCaseName;
    }

    public void setBooKCaseName(String booKCaseName) {
        mBooKCaseName = booKCaseName;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Book book = (Book) o;
        return mCount == book.mCount &&
                Objects.equals(mRFID, book.mRFID) &&
                Objects.equals(mTitle, book.mTitle) &&
                Objects.equals(mName, book.mName) &&
                Objects.equals(mISBN, book.mISBN) &&
                Objects.equals(mID, book.mID) &&
                Objects.equals(mContent, book.mContent) &&
                Objects.equals(mIntroduction, book.mIntroduction) &&
                Objects.equals(mBooKCaseName, book.mBooKCaseName) &&
                Objects.equals(mImageUrl, book.mImageUrl) &&
                Objects.equals(mDate, book.mDate);
    }

    public String getRFID() {
        return mRFID;
    }

    public void setRFID(String RFID) {
        mRFID = RFID;
    }
}
