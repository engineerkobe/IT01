package com.bignerdranch.android.bean;

import java.util.Date;

public class Book {
    //書的標題
    private String mTitle;
    //書的名字
    private String mName;
    //書的ISBN
    private String mISBN;
    //書的RFID
    private String mID;
    //內容
    private String mContent;
    //簡介
    private String mIntroduction;
    //所在書櫃
    private int mBookNumber;
    //有幾本書
    private int mCount;
    //mImagerUrl
    private String mImageUrl;
    private Date mDate;

    public String getTitle() {
        return mTitle;
    }

    public void setTitle(String title) {
        mTitle = title;
    }

    public String getName() {
        return mName;
    }

    public void setName(String name) {
        mName = name;
    }

    public String getISBN() {
        return mISBN;
    }

    public void setISBN(String ISBN) {
        mISBN = ISBN;
    }

    public String getID() {
        return mID;
    }

    public void setID(String ID) {
        mID = ID;
    }

    public String getContent() {
        return mContent;
    }

    public void setContent(String content) {
        mContent = content;
    }

    public String getIntroduction() {
        return mIntroduction;
    }

    public void setIntroduction(String introduction) {
        mIntroduction = introduction;
    }

    public int getBookNumber() {
        return mBookNumber;
    }

    public void setBookNumber(int bookNumber) {
        mBookNumber = bookNumber;
    }

    public int getCount() {
        return mCount;
    }

    public void setCount(int count) {
        mCount = count;
    }

    public String getImageUrl() {
        return mImageUrl;
    }

    public void setImageUrl(String imageUrl) {
        mImageUrl = imageUrl;
    }

    public Date getDate() {
        return mDate;
    }

    public void setDate(Date date) {
        mDate = date;
    }

}
