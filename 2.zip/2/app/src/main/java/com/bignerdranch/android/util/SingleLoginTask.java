package com.bignerdranch.android.util;

import android.os.AsyncTask;
import android.util.Log;

import com.bignerdranch.android.util.Internet;

import java.io.IOException;

//登入時調用
public class SingleLoginTask extends AsyncTask<Void,Void,String> {
    private static final String TAG = "LoginTask";
    private String mFunctionURL;


    public SingleLoginTask(String function) {
        this.mFunctionURL = function;
    }

    @Override
    protected String doInBackground(Void...voids) {
        //取得登入網址
        String url = mFunctionURL;

        Log.d(TAG,url);
        String loginstatus = null;
        try {
            //取得下載下來的網頁內容
            loginstatus = Internet.getUrlString(url);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return loginstatus;
    }




}
