package com.bignerdranch.android.basehelper;

public class BookDbSchema {
    public static final class ISBNBook{
        public static final String NAME = "isbn_book";

        public static final class Cols {
            public static final String NAME = "name";
            public static final String ISBN = "isbn";
            public static final String CONTENT = "content";
            public static final String COUNT = "count";
        }
    }

    public static final class RFIDBook{
        public static final String NAME = "rfid_book";

        public static final class Cols {
            public static final String RFID = "rfid";
            public static final String ISBORROW= "is_borrow";
            public static final String BORROWER = "borrower";
            public static final String LOG = "log";
            public static final String ISBN = "isbn";
        }
    }

    public static final class UserData {
        public static final String NAME = "user_info";

        public static final class Cols {
            public static final String NAME = "name" ;
            public static final String VALUE = "value";
        }
    }
}
