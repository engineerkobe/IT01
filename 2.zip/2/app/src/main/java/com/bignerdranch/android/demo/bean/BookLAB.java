package com.bignerdranch.android.demo.bean;

import android.content.ContentValues;
import android.content.Context;
import android.database.CrossProcessCursor;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.bignerdranch.android.basehelper.BookBaseHelper;
import com.bignerdranch.android.basehelper.BookDbSchema;
import com.bignerdranch.android.bean.ISBNBookWrapper;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;


public class BookLAB {
    private static BookLAB sBookLAB;
    private Context mContext ;

    private SQLiteDatabase mDatabase;

    private BookLAB(Context context) {
       mContext = context.getApplicationContext();
        String UUID[] = { "0A5A2500","A623061D",
                "5593F4E6","96BFAA1D",
                "963E971D","0A9F6300",
                "0A309600","0A397900",
                "0A725000","0A752E00",
                "0AFF3F00"};
        mDatabase = new BookBaseHelper(context).getWritableDatabase();
    }

    public static BookLAB get(Context context) {
       if(sBookLAB == null)
           sBookLAB = new BookLAB(context);
       return sBookLAB;
    }

    public void addBook(Book c) {
        ContentValues contentValues = getContentValues(c);
        if(getBook(c.getISBN())==null)
        mDatabase.insert(BookDbSchema.ISBNBook.NAME,null,contentValues);
    }

    public Book getBook() {
        return null;
    }

    public  Book getBook(String isbn) {
        ISBNBookWrapper cursor = queryISBNBook(
                BookDbSchema.ISBNBook.Cols.ISBN + " = ? ",
                new String[] {isbn}
        );
        try {
            if (cursor.getCount() == 0 ) {
                return null;
            }
            cursor.moveToFirst();
            return cursor.getBook();
        }finally {
            cursor.close();
        }
    }
    private ISBNBookWrapper queryISBNBook(String whereClause, String[] whereArgs) {
        Cursor cursor = mDatabase.query(
                BookDbSchema.ISBNBook.NAME,
                null, // Columns - null selects all columns
                whereClause,
                whereArgs,
                null, // groupBy
                null, // having
                null // orderBy
        );
        return new ISBNBookWrapper(cursor);
    }

    public List<Book> getBooks() {
        List<Book> crimes = new ArrayList<>();
        ISBNBookWrapper cursor = queryISBNBook(null, null);
        try {
            cursor.moveToFirst();
            while (!cursor.isAfterLast()) {
                crimes.add(cursor.getBook());
                cursor.moveToNext();
            }
        } finally {
            cursor.close();
        }
        return crimes;
    }
    /*
        +---------+--------------+------+-----+---------+-------+
        | Field   | Type         | Null | Key | Default | Extra |
        +---------+--------------+------+-----+---------+-------+
        | isbn    | varchar(255) | NO   | PRI | NULL    |       |
        | name    | varchar(255) | NO   |     | NULL    |       |
        | content | text         | NO   |     | NULL    |       |
        | count   | int(11)      | NO   |     | NULL    |       |
        +---------+--------------+------+-----+---------+-------+
     */
    private static ContentValues getContentValues(Book book) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(BookDbSchema.ISBNBook.Cols.ISBN,book.getISBN());
        contentValues.put(BookDbSchema.ISBNBook.Cols.NAME,book.getName());
        contentValues.put(BookDbSchema.ISBNBook.Cols.CONTENT,book.getContent());
        contentValues.put(BookDbSchema.ISBNBook.Cols.COUNT,book.getCount());
        return contentValues;
    }
}
