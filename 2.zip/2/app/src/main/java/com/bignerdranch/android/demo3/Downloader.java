package com.bignerdranch.android.demo3;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Message;

import com.bignerdranch.android.util.Internet;
import com.google.android.gms.tasks.Task;

import java.io.IOException;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

public class Downloader<T> extends HandlerThread {
    private static final int DOWNLOAD_IMAGE = 1;
    private ConcurrentMap<T,String> mConcurrentMap = new ConcurrentHashMap<>();
    private Handler mHandler ;
    private Handler mImageHandler;
    private ThumbnilToHondler<T> linstener;

    public interface ThumbnilToHondler<T>{
       public void SetThumbnilToHandler(T t,Bitmap bitmap);
    }
    void setThumbnilToHondlerListener(ThumbnilToHondler<T> linstener){
        this.linstener  = linstener;
    }

    @Override
    protected void onLooperPrepared() {
        super.onLooperPrepared();

        mHandler = new Handler() {
            @Override
            public void handleMessage(Message msg) {
                switch (msg.what) {
                    case DOWNLOAD_IMAGE:
                        T hondler = (T) msg.obj;
                        String url = mConcurrentMap.get(hondler);
                        downloadThumbnail(hondler,url);
                        break;
                }
            }

        };
    }

    public Downloader(String name, Handler handler) {
        super(name);
        mImageHandler = handler;
    }

    private void downloadThumbnail(final T t, String url) {
        byte [] bytes = null;
        try {
            bytes = Internet.getUrlBytes(url);
        } catch (IOException e) {
            e.printStackTrace();
        }
        final Bitmap bitmap = BitmapFactory.decodeByteArray(bytes,0,bytes.length);
        mImageHandler.post(new Runnable() {
            @Override
            public void run() {
                linstener.SetThumbnilToHandler(t,bitmap);
            }
        });
    }
    public void putDownloadURLAndHondler(T t , String url) {
        if(url == null)
            return;
        else {
            mConcurrentMap.put(t,url);
            mHandler.obtainMessage(DOWNLOAD_IMAGE,t).sendToTarget();
        }
    }
}
