package com.bignerdranch.android.bookpage;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.bignerdranch.android.BookPageActivity;
import com.bignerdranch.android.R;
import com.bignerdranch.android.bean.Book;
import com.bignerdranch.android.bean.RFID;
import com.bignerdranch.android.bookpage.bookpagefragment.BookPagerFragmetntLab;

import java.util.ArrayList;

public class BookPageFragment extends Fragment {


    private ViewPager mViewPager;
    private TabLayout mTabLayout;
    private ArrayList<Fragment> fragments = new ArrayList<>();

    private String[] mTabTitles = new String[]{"最新","热门","我的"};
    private BookPagerFragmetntLab mBookPagerFragmetntLab;
    private Book mBook;
    private RFID mRFID;
    private Button mBorrowButton;
    private static final String EXTRAS_BOOK_ISBN = "com.bignerdranch.android.bookintent.book_isbn";
    private static final String EXTRAS_BOOK_RFID = "com.bignerdranch.android.bookintent.book_rfid";

    public static BookPageFragment newInstance() {
        Bundle args = new Bundle();
//        Book book = BookPageActivity.getBook(intent);
//        RFID rfid = BookPageActivity.getRFID(intent);
//        args.putSerializable(EXTRAS_BOOK_ISBN,book);
//        args.putSerializable(EXTRAS_BOOK_RFID,rfid);
        BookPageFragment bookPageFragment =new BookPageFragment();
        bookPageFragment.setArguments(args);
        return new BookPageFragment();
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent intent = getActivity().getIntent();
        mBook = BookPageActivity.getBook(intent);
        mRFID = BookPageActivity.getRFID(intent);
//        mBook = (Book) getArguments().getSerializable(EXTRAS_BOOK_ISBN);
//        mRFID = (RFID) getArguments().getSerializable(EXTRAS_BOOK_RFID);
//        BookLAB.get(getContext()).getBook(isbn);
//        mBook = new Book();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.book_page_status_bar, container, false);

        mViewPager = (ViewPager) v.findViewById(R.id.book_page_viewpager);
        mTabLayout = (TabLayout) v.findViewById(R.id.book_page_tablayout);
        //設置title
        for(String tmp: mTabTitles)
            mTabLayout.addTab((mTabLayout.newTab()).setText(tmp));

        mViewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(mTabLayout));
        mTabLayout.addOnTabSelectedListener(new TabLayout.ViewPagerOnTabSelectedListener(mViewPager));
        BookPagerFragmetntLab bookPagerFragmetntLab = new BookPagerFragmetntLab(getChildFragmentManager(),mBook,mRFID);
        mViewPager.setOffscreenPageLimit(2);
        mViewPager.setAdapter(bookPagerFragmetntLab.getBookPageFragmentAdatper());
        mBorrowButton = (Button) v.findViewById(R.id.book_page_info_fragment_button);
        return v;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        // TODO: Use the ViewModel
    }

}
