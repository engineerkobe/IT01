package com.bignerdranch.android.demo4;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bignerdranch.android.LoginFragmentActivity;
import com.bignerdranch.android.R;
import com.bignerdranch.android.login.UserLab;

import static com.bignerdranch.android.util.ImageUtil.getImage;


public class Demo4 extends Fragment {
    private static final int GET_IMAGE_FOR_LOCAL = 1;
    private static final int CROP_IMAGE = 2;
    private static final int  SET_NAME = 3;
    private static final int SET_CONFIG = 4;

    private ImageView Head;
    private LinearLayout mLogoutLinearLayout;
    private TextView mUserName;
    private ImageView mHeaderImage;
    private static String TAG = "Demo4";

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.main_account_list_v2,container,false);
        mLogoutLinearLayout = (LinearLayout)v.findViewById(R.id.main_account_logout_linearlayout);
        mHeaderImage = (ImageView) v.findViewById(R.id.main_account_head);
        mUserName =  (TextView) v.findViewById(R.id.main_account_name);
        init();
        //頂部
        return v;
    }

    @Override
    public void onResume() {
        super.onResume();
        String name = UserLab.get(getContext()).getName();
        mUserName.setText(name);

        Bitmap bitmap = getImage(getContext(),"tmp.jpg");
        if(bitmap != null)
            mHeaderImage.setImageBitmap(bitmap);
    }

    private void init() {
        mHeaderImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Intent intent = new Intent(getContext(),AccountConfigActivity.class);
                Intent intent = AccountConfigActivity.newInstance(getActivity());
                startActivityForResult(intent,SET_CONFIG);
//                Intent getImage = new Intent(Intent.ACTION_PICK,MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
//                startActivityForResult(getImage,GET_IMAGE_FOR_LOCAL);

            }
        });

        mLogoutLinearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                UserLab.get(getContext()).deleteTableValues();
                Intent intent = LoginFragmentActivity.newInstance(getContext());
                startActivity(intent);
            }
        });

        Bitmap bitmap = getImage(getContext(),"tmp.jpg");
        if(bitmap != null)
            mHeaderImage.setImageBitmap(bitmap);

        String name = UserLab.get(getContext()).getName();
        if(name == null)
            mUserName.setText(R.string.you_do_not_have_name);
        mUserName.setText(name);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(data == null)
            return;
        if(resultCode != Activity.RESULT_OK)
            return;
        Bitmap bitmap = null;
        switch (requestCode) {
            case SET_CONFIG:
                bitmap = getImage(getContext(),"tmp.jpg");
                if(bitmap != null)
                    mHeaderImage.setImageBitmap(bitmap);
                break;
        }
    }

}
