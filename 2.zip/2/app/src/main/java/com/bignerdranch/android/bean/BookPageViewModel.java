package com.bignerdranch.android.bean;

import android.arch.lifecycle.ViewModel;

public class BookPageViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
