package com.bignerdranch.android.bookpage.bookpagefragment.fragment.adapter.viewholder;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.bignerdranch.android.R;


public class ImageFragment {

    private Context mContext;
    private View view;
    private ViewGroup mViewGroup;


    public ImageFragment(View inflate) {
        this.view=inflate;
    }


    public View create() {
//        View view = inflate.inflate(R.layout.book_page_fragment_container, mViewGroup,false);
        view.setBackgroundResource(R.drawable.ic_launcher_background);
        return view;
    }

}
