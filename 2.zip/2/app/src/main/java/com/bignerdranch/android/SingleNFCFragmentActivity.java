package com.bignerdranch.android;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.nfc.NfcAdapter;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.KeyEvent;
import android.widget.Toast;

import com.bignerdranch.android.config.MyServer;
import com.bignerdranch.android.demo.bean.Book;
import com.bignerdranch.android.util.SingleLoginTask;

import org.json.JSONException;
import org.json.JSONObject;

public abstract class SingleNFCFragmentActivity extends AppCompatActivity {

    private long mExitTime;
    private boolean isOneMoreTimeExit;
    private ConnectivityManager mConnectivityManager;
    private NfcAdapter nfcAdapter;
    private PendingIntent mPendingIntent;

    protected abstract Fragment createFragment();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.book_page_fragment_container);
        FragmentManager fragmentManager = getSupportFragmentManager();
        Fragment fragment = fragmentManager.findFragmentById(R.id.book_page_fragment_container);
        //檢查網路連線
        mConnectivityManager = (ConnectivityManager)  getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = mConnectivityManager.getActiveNetworkInfo();
        //nfc設置
        nfcAdapter = NfcAdapter.getDefaultAdapter(this);
        mPendingIntent = PendingIntent.getActivity(this,0,
                new Intent(this,getClass()).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),0);
//        if(networkInfo.isConnected() ){
        //network == null 代表沒有網路
        if(networkInfo != null ){

            if(fragment == null) {
                fragment = createFragment();
                fragmentManager
                        .beginTransaction()
                        .add(R.id.book_page_fragment_container, fragment)
                        .commit();
            }
        }else
        {
            //查看是否有網路
            Dialog alertDialog = new AlertDialog.Builder(this).
                    setTitle(R.string.internet_error).
                    setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    SingleNFCFragmentActivity.this.finish();
                                }
                            }
                    ).create();
            alertDialog.show();
        }

    }
    //是否開啟在案一次退出
    void setOneMoreTimeExit(boolean oneMoreTimeExit) {
        isOneMoreTimeExit = oneMoreTimeExit;
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        // TODO Auto-generated method stub
        if(isOneMoreTimeExit)
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if ((System.currentTimeMillis() - mExitTime) > 2000) {// 如果两次按键时间间隔大于2000毫秒，则不退出
                Toast.makeText(this, "再按一次退出程序", Toast.LENGTH_SHORT).show();
                mExitTime = System.currentTimeMillis();// 更新mExitTime
            } else {
                System.exit(0);// 否则退出程序
            }
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }


    private String ByteArrayToHexString(byte[] inarray) {
        int i, j, in;
        String[] hex = { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A",
                "B", "C", "D", "E", "F" };
        String out = "";
        for (j = 0; j < inarray.length; ++j) {
            in = (int) inarray[j] & 0xff;
            i = (in >> 4) & 0x0f;
            out += hex[i];
            i = in & 0x0f;
            out += hex[i];
        }
        return out;
    }


    @Override
    protected void onResume() {
        super.onResume();
        nfcAdapter.enableForegroundDispatch(this,mPendingIntent,null,null);
    }

    @Override
    protected void onPause() {
        super.onPause();
        if(nfcAdapter!=null) {
            nfcAdapter.disableForegroundDispatch(this);
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
//        super.onNewIntent(intent);
        if(intent.getAction().equals(NfcAdapter.ACTION_TAG_DISCOVERED)) {
            String tmp = ByteArrayToHexString(intent.getByteArrayExtra(NfcAdapter.EXTRA_ID)) ;
//            Log.d(TAG,tmp );
            new RFIDservices(MyServer.GET_BOOK_FOR_RFID_URL,tmp).execute();
            Toast.makeText(this,tmp  , Toast.LENGTH_LONG).show();
        }
    }
    private class RFIDservices extends SingleLoginTask {


        public RFIDservices(String function, String RFID) {
            super(String.format(function,RFID));
        }
        @Override
        protected void onPostExecute(String s) {
            try {
                JSONObject json = new JSONObject(s);
//                Log.d(TAG,json.toString());
                String isbn = json.getString("isbn");
                String name = json.getString("name");
                String content = json.getString("content");
                int count = json.getInt("count");

                Book book = new Book();
                book.setISBN(isbn);
                book.setContent(content);
                book.setName(name);
                book.setTitle(name);
                book.setCount(count);
                startActivity(BookPageActivity.newInstance(SingleNFCFragmentActivity.this,book));
                finish();
//                mBooks.add(book);
            } catch (JSONException e1) {
                e1.printStackTrace();
            }
        }
    }
}
//
/*
public class MainActivity extends SingleFragmentActivity {
    private NfcAdapter nfcAdapter;
    private PendingIntent mPendingIntent;
    private String TAG = "MainActivity";

    @Override
    public void onCreate(Bundle savedInstanceState ) {
        super.onCreate(savedInstanceState );
        nfcAdapter = NfcAdapter.getDefaultAdapter(this);
        mPendingIntent = PendingIntent.getActivity(this,0,
                new Intent(this,getClass()).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),0);

    }



    @Override
    protected Fragment createFragment() {
//        UserLab.get(this).deleteTableValues();
        //開啟在案一次就退出
        super.setOneMoreTimeExit(true);
        return new MainFragment();

    }

}*/
