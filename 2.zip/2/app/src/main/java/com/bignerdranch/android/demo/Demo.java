package com.bignerdranch.android.demo;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.util.LruCache;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bignerdranch.android.BookPageActivity;
import com.bignerdranch.android.R;
import com.bignerdranch.android.config.MyServer;
import com.bignerdranch.android.bean.Book;
import com.bignerdranch.android.demo.bean.BookLAB;
import com.bignerdranch.android.util.Internet;
import com.bignerdranch.android.util.SingleLoginTask;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Demo extends Fragment {
    private static final String TAG = "Demo" ;
    private RecyclerView mDemoRecyclerView;
    private List<Book> mBooks;
    private BookListDownloader<DemoBookHolder> mBookListDownloader;
    private DemoBookAdapter mDemoBookAdapter;
    private LruCache<String,Bitmap> mLruCache;
    private Handler mHandler;
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mLruCache = new LruCache<>(10*1024*1024);
        mBooks = new ArrayList<>();
//        @SuppressLint("ServiceCast") int memory = ((ActivityManager)getActivity().getSystemService(Context.ACCESSIBILITY_SERVICE)).getMemoryClass()/8;
//        mBooks = BookLAB.get(getActivity()).getBooks();
        new DemoAsyncTack(MyServer.GET_BOOK_LIST_URL).execute();
        Handler responseHandler = new Handler();
        mHandler = new Handler();
//        /*
        mBookListDownloader = new BookListDownloader<>(responseHandler);
        mBookListDownloader.setThumbnailDownloadListener(
                new BookListDownloader.ThumbnailDownloadListener<DemoBookHolder>() {
                    @Override
                    public void onThumbnailDownloaded(DemoBookHolder target, Bitmap thumbnail) {
                        if(isAdded() ) {
                            Drawable drawable = new BitmapDrawable(getResources(), thumbnail);
                            target.bindDrawable(drawable);
                        }

                    }
                });

        mBookListDownloader.start();
        mBookListDownloader.getLooper();
                Log.d(TAG, "Background thread started");
//                */
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mBookListDownloader.quit();
        Log.d(TAG,"Background thread destoryed");
    }

    @SuppressLint("ServiceCast")
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.main_home_book_list,container,false);
        mDemoBookAdapter = new DemoBookAdapter();
        mDemoRecyclerView = (RecyclerView) v.findViewById(R.id.main_home_book_list_recyclerview);
        mDemoRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        mDemoRecyclerView.setAdapter(mDemoBookAdapter);
        return v;
    }
    private class DemoBookAdapter extends RecyclerView.Adapter<DemoBookHolder> {

        @NonNull
        @Override
        public DemoBookHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
            LayoutInflater layoutInflater = LayoutInflater.from(getContext());
            View view = layoutInflater.inflate(R.layout.main_home_book_list_item, viewGroup,false);
            return new DemoBookHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull DemoBookHolder demoBookHolder, int i) {
            String url = String.format(MyServer.GET_BOOK_IMAGE_URL,mBooks.get(i).getISBN());
//           如果緩存沒有就去下載
            mBookListDownloader.queueThumbnail(demoBookHolder,url);
//                if (mLruCache.get(url) == null)
//                    new ImageAsynctask(demoBookHolder).execute(url);
            demoBookHolder.bind(mBooks.get(i));
        }





        @Override
        public int getItemCount() {
            return mBooks.size();
        }
    }

    private class DemoBookHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView mTitle;
        TextView mContext;
        ImageView mImageView;
        Book mBook;
        boolean isPostImage = true;
        public DemoBookHolder(View view) {
            super(view);
            itemView.setOnClickListener(this);
        }

        void bind(Book book) {
            mBook = book;
            mTitle = (TextView)itemView.findViewById(R.id.main_home_book_list_item_title_textview);
            mContext = (TextView)itemView.findViewById(R.id.main_home_book_list_item_content_textview);
            mImageView = (ImageView) itemView.findViewById(R.id.main_home_book_list_item_imageview);
            mTitle.setText(book.getName());
            mContext.setText(book.getContent());
            mContext.setMaxLines(4);
        }
        @Override
        public void onClick(View view) {
            Log.d(TAG,mBook.getISBN());
//            Intent intent = new Intent(getContext(),BookPageActivity.class);
            Intent intent = BookPageActivity.newInstance(getContext(),mBook,null,null);
            startActivity(intent);
        }

        public void bindDrawable(Drawable drawable) {
            if(drawable != null)
            mImageView.setImageDrawable(drawable);
//            mDemoBookAdapter.notifyDataSetChanged();
        }
    }

    /**
     *          +---------+--------------+------+-----+---------+-------+
     * 			| Field   | Type         | Null | Key | Default | Extra |
     * 			+---------+--------------+------+-----+---------+-------+
     * 			| isbn    | varchar(255) | NO   | PRI | NULL    |       |
     * 			| name    | varchar(255) | NO   |     | NULL    |       |
     * 			| content | text         | NO   |     | NULL    |       |
     * 			| count   | int(11)      | NO   |     | NULL    |       |
     * 			+---------+--------------+------+-----+---------+-------+
     */
    class DemoAsyncTack extends SingleLoginTask {

        public DemoAsyncTack(String function) {
            super(function);
        }

        @Override
        protected void onPostExecute(String s) {
            try {
                JSONArray jsonArray = new JSONArray(s);
                Log.d(TAG,jsonArray.toString());
                for(int i = 0; i < jsonArray.length(); i++) {
                    JSONObject json = jsonArray.getJSONObject(i);
                    String isbn = json.getString("isbn");
                    String name = json.getString("name");
                    String content = json.getString("content");
                    int count = json.getInt("count");

                    Book book = new Book();
                    book.setISBN(isbn);
                    book.setContent(content);
                    book.setName(name);
                    book.setTitle(name);
                    book.setCount(count);
                    mBooks.add(book);
                    BookLAB.get(getContext()).addBook(book);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
            mDemoBookAdapter.notifyDataSetChanged();
        }
    }
    private class ImageAsynctask extends AsyncTask<String,Void,Bitmap> {
        DemoBookHolder mDemoBookHolder;
        public ImageAsynctask(DemoBookHolder demoBookHolder) {
           mDemoBookHolder = demoBookHolder;
        }

        @Override
        protected Bitmap doInBackground(String... strings) {
//            mLruCache.put(strings,)
            byte[] bitmapBytes = null;
            try {
                bitmapBytes = Internet.getUrlBytes(strings[0]);
            } catch (IOException e) {
                e.printStackTrace();
            }
            Bitmap bitmap =mLruCache.get(strings[0]);
            bitmap = BitmapFactory
                    .decodeByteArray(bitmapBytes, 0, bitmapBytes.length);
            Log.i(TAG, "Bitmap created");
            mLruCache.put(strings[0],bitmap);
            return bitmap;
        }

        @Override
        protected void onPostExecute(Bitmap bitmap) {
            if(isAdded()) {
                Drawable drawable = new BitmapDrawable(getResources(), bitmap);
                mDemoBookHolder.bindDrawable(drawable);
            }
        }
    }
}
