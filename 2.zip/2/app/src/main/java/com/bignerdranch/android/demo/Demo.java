package com.bignerdranch.android.demo;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bignerdranch.android.BookPageActivity;
import com.bignerdranch.android.R;
import com.bignerdranch.android.config.MyServer;
import com.bignerdranch.android.demo.bean.Book;
import com.bignerdranch.android.demo.bean.BookLAB;
import com.bignerdranch.android.util.SingleLoginTask;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.jar.Attributes;

public class Demo extends Fragment {
    private static final String TAG = "Demo" ;
    private RecyclerView mDemoRecyclerView;
    private List<Book> mBooks;
    private BookListDownloader<DemoBookHolder> mBookListDownloader;
    private DemoBookAdapter mDemoBookAdapter;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mBooks = new ArrayList<>();
//        mBooks = BookLAB.get(getActivity()).getBooks();
        new DemoAsyncTack(MyServer.GET_BOOK_LIST_URL).execute();

        Handler responseHandler = new Handler();

        mBookListDownloader = new BookListDownloader<>(responseHandler);
        mBookListDownloader.setThumbnailDownloadListener(
                new BookListDownloader.ThumbnailDownloadListener<DemoBookHolder>() {
                    @Override
                    public void onThumbnailDownloaded(DemoBookHolder target, Bitmap thumbnail) {
                        if(isAdded()) {
                            Drawable drawable = new BitmapDrawable(getResources(), thumbnail);
                            target.bindDrawable(drawable);
                        }

                    }
                });

        mBookListDownloader.start();
        mBookListDownloader.getLooper();
                Log.d(TAG, "Background thread started");
    }

    @Override
    public void onStop() {
        super.onStop();
        mBookListDownloader.quit();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d(TAG,"Background thread destoryed");
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.main_home_book_list,container,false);
        mDemoBookAdapter = new DemoBookAdapter();
        mDemoRecyclerView = (RecyclerView) v.findViewById(R.id.main_home_book_list_recyclerview);
        mDemoRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        mDemoRecyclerView.setAdapter(mDemoBookAdapter);
        return v;

    }
    private class DemoBookAdapter extends RecyclerView.Adapter<DemoBookHolder> {

        @NonNull
        @Override
        public DemoBookHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
            LayoutInflater layoutInflater = LayoutInflater.from(getContext());
            return new DemoBookHolder(layoutInflater,viewGroup);
        }

        @Override
        public void onBindViewHolder(@NonNull DemoBookHolder demoBookHolder, int i) {
            demoBookHolder.bind(mBooks.get(i));
            String url = String.format("http://192.168.43.166:8080/DemoWeb/GetBookImage?dir=Cover&img=4");
            mBookListDownloader.queueThumbnail(demoBookHolder,url);
        }

        @Override
        public int getItemCount() {
            return mBooks.size();
        }
    }

    private class DemoBookHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView mTitle;
        TextView mContext;
        ImageView mImageView;
        Book mBook;
        public DemoBookHolder(LayoutInflater layoutInflater, ViewGroup viewGroup) {
            super(layoutInflater.inflate(R.layout.main_home_book_list_item, viewGroup,false));

        }

        void bind(Book book) {
            itemView.setOnClickListener(this);
            mBook = book;
            mTitle = (TextView)itemView.findViewById(R.id.main_home_book_list_item_title_textview);
            mContext = (TextView)itemView.findViewById(R.id.main_home_book_list_item_content_textview);
            mImageView = (ImageView) itemView.findViewById(R.id.main_home_book_list_item_imageview);
            mTitle.setText(book.getName());
            mContext.setText(book.getContent());
            mContext.setMaxLines(4);
        }
        @Override
        public void onClick(View view) {
//            Intent intent = new Intent(getContext(),BookPageActivity.class);
            Intent intent = BookPageActivity.newInstance(getContext(),mBook);
            startActivity(intent);
        }

        public void bindDrawable(Drawable drawable) {
            mImageView.setImageDrawable(drawable);
            mDemoBookAdapter.notifyDataSetChanged();
        }
    }

    /**
     *          +---------+--------------+------+-----+---------+-------+
     * 			| Field   | Type         | Null | Key | Default | Extra |
     * 			+---------+--------------+------+-----+---------+-------+
     * 			| isbn    | varchar(255) | NO   | PRI | NULL    |       |
     * 			| name    | varchar(255) | NO   |     | NULL    |       |
     * 			| content | text         | NO   |     | NULL    |       |
     * 			| count   | int(11)      | NO   |     | NULL    |       |
     * 			+---------+--------------+------+-----+---------+-------+
     */
    class DemoAsyncTack extends SingleLoginTask {

        public DemoAsyncTack(String function) {
            super(function);
        }

        @Override
        protected void onPostExecute(String s) {
            try {
                JSONArray jsonArray = new JSONArray(s);
                Log.d(TAG,jsonArray.toString());
                for(int i = 0; i < jsonArray.length(); i++) {
                    JSONObject json = jsonArray.getJSONObject(i);
                    String isbn = json.getString("isbn");
                    String name = json.getString("name");
                    String content = json.getString("content");
                    int count = json.getInt("count");

                    Book book = new Book();
                    book.setISBN(isbn);
                    book.setContent(content);
                    book.setName(name);
                    book.setTitle(name);
                    book.setCount(count);
                    mBooks.add(book);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
            mDemoBookAdapter.notifyDataSetChanged();
        }
    }
}
