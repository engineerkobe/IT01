package com.bignerdranch.android.demo;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.bignerdranch.android.BookPageActivity;
import com.bignerdranch.android.R;
import com.bignerdranch.android.bean.Book;
import com.bignerdranch.android.bean.BookLAB;

import java.util.List;

public class Demo extends Fragment {
    private RecyclerView mDemoRecyclerView;
    private List<Book> mBooks;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mBooks = BookLAB.get(getActivity()).getBooks();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.main_home_book_list,container,false);
        mDemoRecyclerView = (RecyclerView) v.findViewById(R.id.main_home_book_list_recyclerview);
        mDemoRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        mDemoRecyclerView.setAdapter(new DemoBookAdapter());
        return v;

    }
    private class DemoBookAdapter extends RecyclerView.Adapter<DemoBookHolder> {

        @NonNull
        @Override
        public DemoBookHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
            LayoutInflater layoutInflater = LayoutInflater.from(getContext());
            return new DemoBookHolder(layoutInflater,viewGroup);
        }

        @Override
        public void onBindViewHolder(@NonNull DemoBookHolder demoBookHolder, int i) {
            demoBookHolder.bind(mBooks.get(i));
        }

        @Override
        public int getItemCount() {
            return mBooks.size();
        }
    }

    private class DemoBookHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView mTitle;
        TextView mContext;
        Book mBook;
        public DemoBookHolder(LayoutInflater layoutInflater, ViewGroup viewGroup) {
            super(layoutInflater.inflate(R.layout.main_home_book_list_item, viewGroup,false));

        }

        void bind(Book book) {
            itemView.setOnClickListener(this);
            mBook = book;
            mTitle = (TextView)itemView.findViewById(R.id.main_home_book_list_item_title_textview);
            mContext = (TextView)itemView.findViewById(R.id.main_home_book_list_item_content_textview);
            mTitle.setText(book.getName());
            mContext.setText(book.getContent());
            mContext.setMaxLines(4);
        }
        @Override
        public void onClick(View view) {
//            Intent intent = new Intent(getContext(),BookPageActivity.class);
            Intent intent = BookPageActivity.newInstance(getContext(),mBook);
            startActivity(intent);
        }

    }
}
