package com.bignerdranch.android.demo3;

import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bignerdranch.android.R;
import com.bignerdranch.android.bean.Book;
import com.bignerdranch.android.config.MyServer;
import com.bignerdranch.android.login.UserLab;
import com.bignerdranch.android.util.Internet;
import com.bignerdranch.android.util.JSONObjectToBean;

import org.json.JSONArray;
import org.json.JSONException;
import org.w3c.dom.Text;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


public class Demo3 extends Fragment {

    private RecyclerView mRecyclerView;
    private Inadapter mInAdapter;
    private List<Book> mURLList;
    private Downloader<InViewHolder> mInViewHolderDownloader;
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String account = UserLab.get(getContext()).getAccount();
        new GetMyBorrowBook(account).execute();
        mURLList = new ArrayList<>();
        mInViewHolderDownloader = new Downloader<>("download",new Handler());

        mInViewHolderDownloader.setThumbnilToHondlerListener(new Downloader.ThumbnilToHondler<InViewHolder>() {
            @Override
            public void SetThumbnilToHandler(InViewHolder inViewHolder, Bitmap bitmap) {
                inViewHolder.setImageView(bitmap);
            }
        });

        mInViewHolderDownloader.start();
        mInViewHolderDownloader.getLooper();

    }

    @Override
    public void onPause() {
        mInViewHolderDownloader.quit();
        super.onPause();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.main_bookshelf_fragment,container,false);
        mInAdapter = new Inadapter(inflater);
        mRecyclerView = v.findViewById(R.id.main_bookshelf_list_recyclerview);
        mRecyclerView.setLayoutManager(new GridLayoutManager(getContext(),3));
        mRecyclerView.setAdapter(mInAdapter);
        return v;
    }


    private class Inadapter extends RecyclerView.Adapter<InViewHolder> {
        private final LayoutInflater inflater;

        Inadapter(LayoutInflater inflater) {
            this.inflater =  inflater;
        }
        @NonNull
        @Override
        public InViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
            return new InViewHolder(inflater,viewGroup);
        }

        @Override
        public void onBindViewHolder(@NonNull InViewHolder mViewHolder, int i) {
//            mViewHolder.setTitle(String.valueOf(i));
            Book book = mURLList.get(i);
            String url = book.getImageUrl();

            mInViewHolderDownloader.putDownloadURLAndHondler(mViewHolder,url);
            mViewHolder.bind(book);
        }

        @Override
        public int getItemCount() {
            return mURLList.size();
        }

    }
    private class InViewHolder extends RecyclerView.ViewHolder {
        private ImageView mImageView;
        private TextView mTextView;

        public InViewHolder(LayoutInflater inflater, ViewGroup container) {
            super(inflater.inflate(R.layout.main_bookshelf_fragment_1_item,container,false));
            mImageView = (ImageView) itemView.findViewById(R.id.main_bookshelf_list_recyclerview_item_imageview);
            mTextView = (TextView) itemView.findViewById(R.id.main_bookshelf_list_recyclerview_item_textview);
        }



        public void bind(Book book) {

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                }
            });
            mTextView.setText(book.getName());
        }

        public void setImageView(Bitmap bitmap) {
            mImageView.setImageBitmap(bitmap);
        }
    }

    private class  GetMyBorrowBook extends AsyncTask<String,Void,String> {
        private String mAccount;

        public GetMyBorrowBook(String account) {
            mAccount = account;
        }

        @Override
        protected void onPostExecute(String s) {
            if(s.equals("NoArrayBorrowedBook"))
                Toast.makeText(getContext(),s,Toast.LENGTH_SHORT).show();
            mInAdapter.notifyDataSetChanged();
        }

        @Override
        protected String doInBackground(String... strings) {
            String url = String.format(MyServer.GET_BORROWED_BOOK_LIST_URL,mAccount);
            String content = null;
            try {
                content= Internet.getUrlString(url);
            } catch (IOException e) {
                e.printStackTrace();
            }
            if(content.equals("NoArrayBorrowedBook")!=true) {
                JSONArray jsonArray = null;
                try {
                    jsonArray = new JSONArray(Internet.getUrlString(url));
                } catch (JSONException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                for (int i = 0; i < jsonArray.length(); i++) {
                    Book book = null;
                    try {
                        book = JSONObjectToBean.JSONObjectToBook(jsonArray.getJSONObject(i));
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    mURLList.add(book);
                }
            }
            return content;
        }
    }
}
