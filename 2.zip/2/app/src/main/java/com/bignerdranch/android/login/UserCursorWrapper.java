package com.bignerdranch.android.login;

import android.database.Cursor;
import android.database.CursorWrapper;

import com.bignerdranch.android.basehelper.BookDbSchema;


public class UserCursorWrapper extends CursorWrapper {
    public UserCursorWrapper(Cursor cursor) {
        super(cursor);
    }

    public String getUserData() {
        String password = getString(getColumnIndex(BookDbSchema.UserData.Cols.VALUE));
        return password;
    }
}
