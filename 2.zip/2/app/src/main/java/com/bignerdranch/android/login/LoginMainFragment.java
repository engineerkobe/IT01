package com.bignerdranch.android.login;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.bignerdranch.android.R;

public class LoginMainFragment extends Fragment {

    private FragmentManager fm;
    private TextView mRegisterTextview;
    private RegisterFragment mRegisterFragment;
    private LoginFragment mLoginFragment;

    public static LoginMainFragment newInstance() {

        Bundle args = new Bundle();

        LoginMainFragment fragment = new LoginMainFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        fm = getChildFragmentManager();
        mRegisterFragment = RegisterFragment.newInstance();
        mLoginFragment = LoginFragment.newInstance();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.book_login_main,container,false);
        mRegisterTextview = (TextView)v.findViewById(R.id.book_login_main_register_textview);
        fm.beginTransaction().add(R.id.book_login_main_framelayout,mRegisterFragment);
        fm.beginTransaction().add(R.id.book_login_main_framelayout,mLoginFragment).commit();
        mRegisterTextview.setOnClickListener(new View.OnClickListener(){
            private boolean key = true;
            @Override
            public void onClick(View v) {
                if(key) {
                    fm.beginTransaction().replace(R.id.book_login_main_framelayout,mRegisterFragment).commit();
                    mRegisterTextview.setText(R.string.login);
                    key = !key;
                }else{
                    fm.beginTransaction().replace(R.id.book_login_main_framelayout,mLoginFragment).commit();
                    mRegisterTextview.setText(R.string.register);
                    key = !key;
                }
//                fm.beginTransaction().replace(R.id.book_login_main_framelayout,RegisterFragment.newInstance()).commit();
            }
        });
        return v;
    }
}
