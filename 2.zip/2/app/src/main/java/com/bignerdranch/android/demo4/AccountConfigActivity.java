package com.bignerdranch.android.demo4;

import android.content.Context;
import android.content.Intent;
import android.support.v4.app.Fragment;

import com.bignerdranch.android.SingleFragmentActivity;
import com.bignerdranch.android.demo4.fragment.ConfigMainFragment;
import com.bignerdranch.android.demo4.fragment.ConfigNameFragment;
import com.bignerdranch.android.login.LoginFragment;

public class AccountConfigActivity extends SingleFragmentActivity {
    private static String WHAT_IS_FRAGMENT= "AccountConfigActivity.name";
    static final int MAIN_FRAGMENT = 1;
    static final int CONFIG_NAME = 2;
    public static Intent newInstance(Context content) {
        Intent intent = new Intent(content,AccountConfigActivity.class);
        intent.putExtra(WHAT_IS_FRAGMENT,MAIN_FRAGMENT);
        return intent;
    }
    public static Intent setName(Context context) {
        Intent intent = new Intent(context,AccountConfigActivity.class);
        intent.putExtra(WHAT_IS_FRAGMENT,CONFIG_NAME);
        return intent;
    }

    @Override
    protected Fragment createFragment() {
        int t = getIntent().getIntExtra(WHAT_IS_FRAGMENT,0);
        if(t == MAIN_FRAGMENT)
            return ConfigMainFragment.newInstance();
        else if (t == CONFIG_NAME)
            return ConfigNameFragment.newInstance();
        else
            return LoginFragment.newInstance();
    }
}
