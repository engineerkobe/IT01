package com.bignerdranch.android.login;

import android.content.ContentValues;
import android.content.Context;
import android.content.MutableContextWrapper;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.bignerdranch.android.basehelper.BookBaseHelper;
import com.bignerdranch.android.basehelper.BookDbSchema;
import com.bignerdranch.android.config.MyUser;


public class UserLab {
    private Context mContext;
    private SQLiteDatabase mDatabase;
    private static UserLab sUserLab = null;

    private UserLab(Context context) {
        if(mContext == null)
            mContext = context.getApplicationContext();
        mDatabase = new BookBaseHelper(context).getWritableDatabase();
    }
    //把表單清空
    public void deleteTableValues() {
       mDatabase.delete(BookDbSchema.UserData.NAME,null,null) ;
    }

    public static UserLab get(Context context) {
        if(sUserLab == null)
            sUserLab = new UserLab(context);
        return sUserLab;
    }

     public MyUser getUser() {
        String accound = getAccount();
        String password = getPassword();
        String name  = getName();

        MyUser.setAccount(accound);
        MyUser.setPassword(password);
        MyUser.setName(name);
        if(getAccount() == null || getPassword() == null)
            return null;
        else
            return new MyUser();
    }

    
    //保存名字
    public void saveName(String name) {
        ContentValues namedata = put("name",name);
        if(getValue("name")==null)//如果本地沒找到名字 就寫入資料庫
            mDatabase.insert(BookDbSchema.UserData.NAME,null,namedata);
        else//如果有就更新本地的名字
            mDatabase.update(BookDbSchema.UserData.NAME,namedata,"name=?",new String[]{"name"});

    }
    public void savePassword(String password) {
        ContentValues passwordData = put("password",password);
        mDatabase.insert(BookDbSchema.UserData.NAME,null,passwordData);
    }
    public void saveAccound(String account) {
        ContentValues accountData= put("account", account);
        mDatabase.insert(BookDbSchema.UserData.NAME,null,accountData);

    }
    
    public String getAccount() {
        String name = getValue("account");
        return name;
    }
    public String getPassword() {
        String name = getValue("password");
        return name;
    }

    public String getName() {
        String name = getValue("name");
        return name;
    }
    /**
     * 儲存數據寫入資料庫
     * key = 鍵
     * value = 值
     */
    private static ContentValues put(String key, String value) {
        ContentValues values = new ContentValues();
        values.put(BookDbSchema.UserData.Cols.NAME,key);
        values.put(BookDbSchema.UserData.Cols.VALUE,value);
        return values;
    }

    private Cursor queryUser(String whereClause,String[] whereArgs) {
        Cursor cursor = mDatabase.query(
                BookDbSchema.UserData.NAME,
                null,
                whereClause,
                whereArgs,
                null,
                null,
                null
        );
        return cursor;
    }

    //讀取資料
    //data : 要查詢的鍵
    //回傳:值
    public String getValue(String data) {
        Cursor cursor = queryUser(
                BookDbSchema.UserData.Cols.NAME  + " = ? " ,
                new String[] {data}
        );
        try {
            if(cursor.getCount() ==0 ) {
                return null;
            }
            cursor.moveToFirst();
            int index  = cursor.getColumnIndex(BookDbSchema.UserData.Cols.VALUE);
            return cursor.getString(index);
        }finally {
            cursor.close();
        }
    }
}
