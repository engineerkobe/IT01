package com.bignerdranch.android.login;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.bignerdranch.android.basehelper.BookBaseHelper;
import com.bignerdranch.android.basehelper.BookDbSchema;
import com.bignerdranch.android.login.bean.User;


public class UserLab {
    private Context mContext;
    private SQLiteDatabase mDatabase;
    private static UserLab sUserLab = null;

    private UserLab(Context context) {
        mContext = context.getApplicationContext();
        mDatabase = new BookBaseHelper(context).getWritableDatabase();
    }

    public static UserLab get(Context context) {
        if(sUserLab == null)
            sUserLab = new UserLab(context);
        return sUserLab;
    }
    //儲存帳號密碼
    //插入資料
    public void saveLoginData(String account,String password) {
       ContentValues accountData= getContentValues("account", account);
       ContentValues passwordData = getContentValues("password",password);
       mDatabase.insert(BookDbSchema.UserData.NAME,null,accountData);
       mDatabase.insert(BookDbSchema.UserData.NAME,null,passwordData);
    }
    /*
     *  如果沒有登入過救回傳null
     */
    public User getLoginData() {
        User user = new User();
        String account = getUserData("account") ;
        String password = getUserData("password");
        if(account != null && password != null) {
            user.setAccount(account);
            user.setPassword(password);
            return user;
       }
       else
            return null;
    }
    /**
     * 儲存數據寫入資料庫
     * name = 鍵
     * values = 值
     */
    private static ContentValues getContentValues(String name,String value) {
        ContentValues values = new ContentValues();
        values.put(BookDbSchema.UserData.Cols.NAME,name);
        values.put(BookDbSchema.UserData.Cols.VALUE,value);
        return values;
    }

    private UserCursorWrapper queryUser(String whereClause,String[] whereArgs) {
        Cursor cursor = mDatabase.query(
                BookDbSchema.UserData.NAME,
                null,
                whereClause,
                whereArgs,
                null,
                null,
                null
        );
        return new UserCursorWrapper(cursor);
    }

    //讀取資料
    //data : 要查詢的鍵
    //回傳:值
    public String getUserData(String data) {
        UserCursorWrapper cursor = queryUser(
                BookDbSchema.UserData.Cols.NAME  + " = ? " ,
                new String[] {data}
        );
        try {
            if(cursor.getCount() ==0 ) {
                return null;
            }
            cursor.moveToFirst();
            return cursor.getUserData();
        }finally {
            cursor.close();
        }
    }
}
