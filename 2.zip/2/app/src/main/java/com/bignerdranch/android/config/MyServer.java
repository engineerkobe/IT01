package com.bignerdranch.android.config;

import android.content.Context;

import com.bignerdranch.android.login.UserLab;

public class MyServer {
//    public static final String IP = "192.168.43.166";
    public static final String IP = "115.126.25.114";
    public static final String GET_BOOK_LIST_URL = String.format(MyHttp.GET_BOOK_LIST,IP);
    public static final String GET_BOOK_IMAGE_URL= String.format(MyHttp.GET_BOOK_IMAGE,IP,"%s");
    public static final String GET_BOOK_FOR_RFID_URL = String.format(MyHttp.GET_BOOK_FOR_RFID,IP,"%s");
    public static final String BORROWBOOK_URL = String.format(MyHttp.BORROWBOOK,IP);
    public static final String JOIN_ACCOUNT_URL = String.format(MyHttp.JOIN_ACCOUNT,IP) ;
    public static final String GET_BORROWED_BOOK_LIST_URL = String.format(MyHttp.GET_BOWWOWED_BOOK_LIST,IP,"%s");
    public static final String PUT_IMAGE_URL = String.format(MyHttp.PUT_IMAGE,IP);
    public static final String LOGIN_URL = String.format(MyHttp.LOGIN,IP,"%s","%s");
    public static final String PUT_URL =  String.format(MyHttp.POST,IP);
    public static final String GET_ARTICLE_LIST_URL = String.format(MyHttp.GET_ARTICLE_LIST,IP);
    public static final String GET_ARTICLE_LIST_ROOTID_URL = String.format(MyHttp.GET_ARTICLE_LIST_ROOTID,IP,"%s");

    static class MyHttp {
        static final String GET_BOWWOWED_BOOK_LIST = "http://%s:8080/DemoWeb/GetBorrowedBookList?account=%s" ;
        static final String JOIN_ACCOUNT = "http://%s:8080/DemoWeb/JoinAccount";
        static final String BORROWBOOK = "http://%s:8080/DemoWeb/BorrowBook";
        static final String LOGIN =  "http://%s:8080/DemoWeb/LoginServlet?username=%s&pwd=%s";
        static final String GET_BOOK_LIST = "http://%s:8080/DemoWeb/GetBookList";
        static final String GET_BOOK_IMAGE = "http://%s:8080/DemoWeb/GetBookImage?dir=Cover&img=%s";
        static final String GET_BOOK_FOR_RFID = "http://%s:8080/DemoWeb/GetBookForRFID?RFID=%s";
        static final String PUT_IMAGE = "http://%s:8080/DemoWeb/PutImage";
        static final String POST = "http://%s:8080/DemoWeb/Post";
        static final String GET_ARTICLE_LIST = "http://%s:8080/DemoWeb/GetArticleList";
        static final String GET_ARTICLE_LIST_ROOTID = "http://%s:8080/DemoWeb/GetArticleList?rootid=%s";
    }
}
