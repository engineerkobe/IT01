package com.bignerdranch.android.config;

import android.content.Context;

import com.bignerdranch.android.login.UserLab;
import com.bignerdranch.android.login.bean.User;

public class MyServer {
    public static final String IP = "192.168.43.166";
    public static final String GET_BOOK_LIST_URL = String.format(MyHttp.GET_BOOK_LIST,IP);
    public static final String GET_BOOK_IMAGE_URL= String.format(MyHttp.GET_BOOK_IMAGE,IP,"%s");
    public static final String GET_BOOK_FOR_RFID_URL = String.format(MyHttp.GET_BOOK_FOR_RFID,IP,"%s");
    public static String LOGIN_URL;
    public static String mAccount;
    public static String mPassword;
    public static boolean logingIsSuccess(Context context) {
        User user =  getUserForDatabase(context);
        if(user!=null) {
            mAccount = user.getAccount();
            mPassword = user.getPassword();
            return true;
        }
        return false;
    }
    public static void get(Context context,String account,String password) {
        User user = getUserForDatabase(context);
        if(user==null) {
            mAccount = account;
            mPassword = password;
        }
        LOGIN_URL = String.format(MyHttp.LOGIN_URL_MODEL, IP,account,password);
    }
    private static User getUserForDatabase(Context context) {
        return UserLab.get(context).getLoginData();
    }
    static class MyHttp {
        static final String LOGIN_URL_MODEL =  "http://%s:8080/DemoWeb/LoginServlet?username=%s&pwd=%s";
        static final String GET_BOOK_LIST = "http://%s:8080/DemoWeb/GetBookList";
        static final String GET_BOOK_IMAGE = "http://%s:8080/DemoWeb/GetBookImage?dir=Cover&img=%s";
        static final String GET_BOOK_FOR_RFID = "http://%s:8080/DemoWeb/GetBookForRFID?RFID=%s";
    }
}
