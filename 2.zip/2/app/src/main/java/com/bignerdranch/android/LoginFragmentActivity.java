package com.bignerdranch.android;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;

import com.bignerdranch.android.login.LoginFragment;

public class LoginFragmentActivity extends SingleFragmentActivity {
    public static Intent newInstance(Context context) {
        Intent intent = new Intent(context,LoginFragmentActivity.class);
        return intent;
    }
    @Override
    protected Fragment createFragment() {
        return LoginFragment.newInstance();
    }
}
