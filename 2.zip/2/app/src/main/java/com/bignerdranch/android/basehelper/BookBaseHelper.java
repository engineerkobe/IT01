package com.bignerdranch.android.basehelper;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.annotation.Nullable;

public class BookBaseHelper extends SQLiteOpenHelper {
    private static final int VERSION = 1;
    private static final String DATABASE_NAME = "book";

    public BookBaseHelper(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        /*db.execSQL("CREATE TABLE " + BookDbSchema.BookTable.NAME + "(" +
                " _id integer primary key autoincrement, "  +
                BookDbSchema.BookTable.Cols.TITLE+
                BookDbSchema.BookTable.Cols.NAME+
                BookDbSchema.BookTable.Cols.ISBN+
                BookDbSchema.BookTable.Cols.ID+
                BookDbSchema.BookTable.Cols.CONTENT+
                BookDbSchema.BookTable.Cols.INTRODUCTION+
                BookDbSchema.BookTable.Cols.BOOKNUMBER+
                BookDbSchema.BookTable.Cols.COUNT+
                BookDbSchema.BookTable.Cols.IMAGE_URL+
                BookDbSchema.BookTable.Cols.DATE+
                " ) "
        );*/
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
