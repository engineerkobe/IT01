package com.bignerdranch.android.rfid;

import java.util.Date;

public class RFIDBook {
    private String mRFID;
    private String mBorrow;
    private Date mDate;
    private String mISBN;

}
