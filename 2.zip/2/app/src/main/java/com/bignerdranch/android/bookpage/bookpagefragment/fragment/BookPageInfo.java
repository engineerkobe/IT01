package com.bignerdranch.android.bookpage.bookpagefragment.fragment;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.bignerdranch.android.R;
import com.bignerdranch.android.demo.bean.Book;
import com.bignerdranch.android.demo.bean.BookLAB;
import com.bignerdranch.android.bookpage.bookpagefragment.fragment.adapter.BookPageInfoAdapter;
import com.bignerdranch.android.bookpage.bookpagefragment.fragment.adapter.BookPageInfoItemDecoration;

import java.io.Serializable;

public class BookPageInfo extends Fragment {
    private static final String FM = "FragmentManager";
    private RecyclerView mRecyclerView;
    private Book mBook;
    private Context mConText;


    public static BookPageInfo newInstance(Book book) {
        Bundle args = new Bundle();
        args.putSerializable("book",book.getISBN());
        BookPageInfo fragment = new BookPageInfo();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        mBook =(String) getArguments().getSerializable("book");
        String tmp =(String) getArguments().getSerializable("book");
        mBook = BookLAB.get(getContext()).getBook(tmp);

//        getArguments().getSerializable(FM);
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.book_page_info_fragment, container, false);
        mRecyclerView = (RecyclerView)v.findViewById(R.id.book_page_info_fragment_recyclerview);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        mRecyclerView.addItemDecoration(new BookPageInfoItemDecoration());
        mRecyclerView.setAdapter(new BookPageInfoAdapter(inflater,container,getChildFragmentManager(),mBook));
        return v;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        // TODO: Use the ViewModel
    }

}
