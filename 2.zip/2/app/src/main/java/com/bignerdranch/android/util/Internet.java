package com.bignerdranch.android.util;

import android.util.Log;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class Internet {
    private static final String TAG =Internet.class.getName() ;

    public static String postUrl(String urlSpec, String post) throws IOException {
        URL url = new URL(urlSpec);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("POST");
        connection.setDoInput(true);
        connection.setDoOutput(true);

        BufferedOutputStream bos = new BufferedOutputStream(connection.getOutputStream());
        bos.write(post.getBytes("UTF-8"));
        bos.flush();
        bos.close();
        if(connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
            BufferedInputStream bis = new BufferedInputStream(connection.getInputStream());
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            byte[] buffer = new byte[1024];
            for(int bytesRead=0; (bytesRead = bis.read(buffer)) != -1; )
                baos.write(buffer,0,bytesRead);
            String result = new String(baos.toByteArray());
            Log.d(TAG,result);
            return result;
        }
        return null;
    }
    public static byte[] getUrlBytes(String urlSpec) throws IOException {
        URL url = new URL(urlSpec);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            InputStream in = url.openStream();

            if(connection.getResponseCode() != HttpURLConnection.HTTP_OK) {
                throw new IOException(connection.getResponseMessage() + ": with " + urlSpec);
            }
            byte[] buffer = new byte[1024];

            for(int bytesRead=0; (bytesRead = in.read(buffer)) != -1; )
                out.write(buffer,0,bytesRead);
            out.close();
            in.close();
            return out.toByteArray();

        }finally {
            connection.disconnect();
        }
    }
    public static String getUrlString(String urlSpec) throws IOException {
        return new String(getUrlBytes(urlSpec));
    }


}
