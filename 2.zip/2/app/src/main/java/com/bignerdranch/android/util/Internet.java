package com.bignerdranch.android.util;

import android.content.Context;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.util.Log;

import com.bignerdranch.android.config.MyServer;
import com.bignerdranch.android.login.UserLab;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Internet {
    private static final String TAG =Internet.class.getName() ;

    private static String sboundary= "----SomeRandomText";

    public static String postUrl(String urlSpec, String post) throws IOException {
        URL url = new URL(urlSpec);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("POST");
        connection.setDoInput(true);
        connection.setDoOutput(true);

        BufferedOutputStream bos = new BufferedOutputStream(connection.getOutputStream());
        bos.write(post.getBytes("UTF-8"));
        bos.flush();
        bos.close();
        if(connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
            BufferedInputStream bis = new BufferedInputStream(connection.getInputStream());
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            byte[] buffer = new byte[1024];
            for(int bytesRead=0; (bytesRead = bis.read(buffer)) != -1; )
                baos.write(buffer,0,bytesRead);
            String result = new String(baos.toByteArray());
            Log.d(TAG,result);
            return result;
        }
        return null;
    }
    public static byte[] getUrlBytes(String urlSpec) throws IOException {
        URL url = new URL(urlSpec);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            InputStream in = url.openStream();

            if(connection.getResponseCode() != HttpURLConnection.HTTP_OK) {
                throw new IOException(connection.getResponseMessage() + ": with " + urlSpec);
            }
            byte[] buffer = new byte[1024];

            for(int bytesRead=0; (bytesRead = in.read(buffer)) != -1; )
                out.write(buffer,0,bytesRead);
            out.close();
            in.close();
            return out.toByteArray();

        }finally {
            connection.disconnect();
        }
    }

    public static String getUrlString(String urlSpec) throws IOException {
        return new String(getUrlBytes(urlSpec));
    }


    public static String postFile(Context context,File f) throws IOException, InterruptedException {
        //設定post方法
        URL url = new URL(MyServer.PUT_IMAGE_URL);
        HttpURLConnection urlc = (HttpURLConnection) url.openConnection();
        urlc.setRequestMethod("POST");
        urlc.setRequestProperty("Content-Type", "multipart/form-data; charset=UTF-8;boundary="+sboundary);
        urlc.setDoOutput(true);
        urlc.setDoInput(true);
        //讀取檔案寫入內存
        byte [] filebytes = new byte[1024];
        FileInputStream fis = new FileInputStream(f);
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        for(int tmp; (tmp=fis.read(filebytes))!= -1;)
            baos.write(filebytes, 0, tmp);

        filebytes = baos.toByteArray();
        fis.close();
        //account帳號當 照片名稱
        String filename = UserLab.get(context).getAccount().trim();
        //發送post數據
        OutputStreamWriter osw = new OutputStreamWriter(urlc.getOutputStream(),"UTF-8");
        addFileData("file",filename+".jpg",filebytes,new PrintWriter(osw), urlc.getOutputStream(),sboundary) ;
        String tmpString = null;
        //接收網頁
        if (HttpURLConnection.HTTP_OK == urlc.getResponseCode()) {
            showField(urlc.getHeaderFields());
            InputStreamReader isr = new InputStreamReader(urlc.getInputStream(), "UTF-8");
            char[] chars = new char[1024];
            for (int tmp; (tmp = isr.read(chars)) != -1;)
                tmpString += new String (chars);
            isr.close();
            return tmpString;
//                System.out.println(chars);
        }else {
            System.out.println(urlc.getResponseCode());
        }
        osw.close();
        urlc.disconnect();
        return tmpString;
    }

    private static void addFileData(String paramName, String filename, byte[] byteStream, PrintWriter body,
                                    OutputStream directOutput, final String boundary) throws IOException {
        body.append("--").append(boundary).append("\r\n");
        body.append("Content-Disposition:form-data; name=\"" + paramName + "\"; filename=\"" + filename + "\"")
                .append("\r\n");
        body.append("Content-Type:application/octet-stream").append("\r\n");
        body.append("\r\n");
        body.flush();

        directOutput.write(byteStream);
        directOutput.flush();

        body.append("\r\n--").append(sboundary).append("--\r\n");
        body.flush();
    }



    private static void showField(Map<String, List<String>> headerFields) {
        // TODO Auto-generated method stub
        Set<Map.Entry<String, List<String>>> headerfieldSet = headerFields.entrySet();
        Iterator<Map.Entry<String, List<String>>> headerfildIT= headerfieldSet.iterator();
        while(headerfildIT.hasNext()) {
            Map.Entry<String,List<String>> headerfildEntry =  headerfildIT.next();
            String key = headerfildEntry.getKey() + ":";
            for(String tmp : headerfildEntry.getValue()) {
                key = key + tmp+ ",";
            }
            Log.d(TAG,key);
        }
    }
}
