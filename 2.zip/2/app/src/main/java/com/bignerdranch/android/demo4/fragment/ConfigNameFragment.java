package com.bignerdranch.android.demo4.fragment;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.bignerdranch.android.R;
import com.bignerdranch.android.login.UserLab;
import com.bignerdranch.android.util.Internet;

import java.io.File;
import java.io.IOException;

public class ConfigNameFragment extends Fragment {
    private EditText mEditText;
    private Button mButton;

    public static ConfigNameFragment newInstance() {

        Bundle args = new Bundle();

        ConfigNameFragment fragment = new ConfigNameFragment();
        fragment.setArguments(args);
        return fragment;
    }
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.main_account_config_name_fragment,container,false);
        mEditText = (EditText) v.findViewById(R.id.main_account_config_name_fragment_edittext);
        mButton = (Button) v.findViewById(R.id.main_account_config_name_fragment_save_name);
        init();
        return v;
    }

    private void init() {
        mButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
               String name = mEditText.getText().toString();
               name = name.trim();
               UserLab.get(getContext()).saveName(name);
                Toast.makeText(getContext(),"set name success",Toast.LENGTH_SHORT).show();
            }
        });
    }

    //上傳圖片的線程
    class PostTask extends AsyncTask<Void,Void,String> {
        private Context mContext;
        private File mFile = null;

        public PostTask(Context context, File file) {
            mContext = context;
            mFile = file;
        }

        @Override
        protected String doInBackground(Void...voids) {
            //取得登入網址

            String loginstatus = null;
            try {
                //取得下載下來的網頁內容
                loginstatus = Internet.postFile(mContext,mFile);
            } catch (IOException e) {
                e.printStackTrace();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            return loginstatus;
        }

        @Override
        protected void onPostExecute(String s) {
            Toast.makeText(mContext,s,Toast.LENGTH_SHORT).show();
        }
    }

}
