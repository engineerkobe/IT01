package com.bignerdranch.android.demo4.fragment;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.bignerdranch.android.R;
import com.bignerdranch.android.config.MyUser;
import com.bignerdranch.android.demo4.AccountConfigActivity;
import com.bignerdranch.android.login.UserLab;
import com.bignerdranch.android.util.Internet;

import java.io.File;
import java.io.IOException;

public class ConfigNameFragment extends Fragment {
    private EditText mEditText;
    private Button mButton;

    public static ConfigNameFragment newInstance() {

        Bundle args = new Bundle();

        ConfigNameFragment fragment = new ConfigNameFragment();
        fragment.setArguments(args);
        return fragment;
    }
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.main_account_config_name_fragment,container,false);
        mEditText = (EditText) v.findViewById(R.id.main_account_config_name_fragment_edittext);
        mButton = (Button) v.findViewById(R.id.main_account_config_name_fragment_save_name);
        init();
        return v;
    }

    private void init() {
        mButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
               String name = mEditText.getText().toString().trim();
               UserLab.get(getContext()).saveName(name);
               new PostTask(getContext(),MyUser.getAccount(),name).execute();

                Toast.makeText(getContext(),"set name success",Toast.LENGTH_SHORT).show();
            }
        });
    }

    //上傳圖片的線程
    class PostTask extends AsyncTask<Void,Void,String> {
        private Context mContext;
        private String mAccount;
        private String mName;

        public PostTask(Context context, String account, String name) {
            mContext = context;
            mAccount = account;
            mName = name;
        }

        @Override
        protected String doInBackground(Void...voids) {
            String status = null;
            try {
                status = Internet.postSetUserName(getContext(), mAccount,mName);
            } catch (IOException e) {
                e.printStackTrace();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            return status;
        }

        @Override
        protected void onPostExecute(String s) {
            Toast.makeText(mContext,s,Toast.LENGTH_SHORT).show();
        }
    }

}
