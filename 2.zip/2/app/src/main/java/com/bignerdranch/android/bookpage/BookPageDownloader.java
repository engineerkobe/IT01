package com.bignerdranch.android.bookpage;

import android.os.Handler;
import android.os.HandlerThread;
import android.os.Message;
import android.util.Log;

import com.bignerdranch.android.bean.Book;
import com.bignerdranch.android.demo.bean.BookLAB;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.concurrent.ConcurrentMap;


public class BookPageDownloader<T> extends HandlerThread {
    private static final String TAG = "BookPagerDownloader";
    private Handler mHandler;
    private static final int MESSAGE_DOWNLOAD_INFO = 1;
    private static final int MESSAGE_DOWNLOAD_REVIEWS = 2;
    private ConcurrentMap<String,String> mBook;

    interface BookPageInfoInterface {
    }
    public BookPageDownloader(String name) {
        super(name);
    }

    @Override
    protected void onLooperPrepared() {
        mHandler = new Handler(this.getLooper()) {

            @Override
            public void handleMessage(Message msg) {
                switch(msg.what) {
                    case MESSAGE_DOWNLOAD_INFO:
                        break;
                    case MESSAGE_DOWNLOAD_REVIEWS:
                        init();
                        T tager = (T) msg.obj;
                        handleRquest(tager);
                        break;
                }
            }


        };
    }

    private void init() {
    }
    private void handleRquest(T tager) {
//        byte[] bitmapByte = Internet.getUrlBytes();
    }

}
