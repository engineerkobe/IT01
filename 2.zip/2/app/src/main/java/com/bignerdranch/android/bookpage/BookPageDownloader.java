package com.bignerdranch.android.bookpage;

import android.os.Handler;
import android.os.HandlerThread;
import android.os.Message;

public class BookPageDownloader extends HandlerThread {
    private static final String TAG = "BookPagerDownloader";
    Handler mHandler;
    public BookPageDownloader() {
        super(TAG);

        mHandler = new Handler(){
            @Override
            public void handleMessage(Message msg) {
                super.handleMessage(msg);
            }
        };
    }
    public void queueThumbnail() {

    }
}
