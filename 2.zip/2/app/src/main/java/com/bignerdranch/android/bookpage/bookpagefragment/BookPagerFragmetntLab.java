package com.bignerdranch.android.bookpage.bookpagefragment;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.view.ViewGroup;

import com.bignerdranch.android.bean.Book;
import com.bignerdranch.android.bookpage.bookpagefragment.fragment.BookPageInfo;
import com.bignerdranch.android.bookpage.bookpagefragment.fragment.BookPageLendingLog;
import com.bignerdranch.android.bookpage.bookpagefragment.fragment.BookPageReviews;

import java.util.ArrayList;
import java.util.List;

public class BookPagerFragmetntLab {

    private FragmentManager mChildFragmentManager;
    private BookPageInfo f1;
    private BookPageReviews f2;
    private BookPageLendingLog f3;
    private Context mContext;
    private ArrayList<Fragment> mFragmetList;
    private BookPageFragmetAdapter mBookPageFragmentAdatper;
    private static BookPagerFragmetntLab sBookPagerFragmetntLab;

    public BookPagerFragmetntLab(FragmentManager childFragmentManager, Book book) {
        mFragmetList = new ArrayList<>();
        mChildFragmentManager = childFragmentManager;
        f1 = BookPageInfo.newInstance(book);
        f2 = new BookPageReviews();
        f3 = new BookPageLendingLog();
        mFragmetList.add(f1);
        mFragmetList.add(f2);
        mFragmetList.add(f3);
        mBookPageFragmentAdatper = new BookPageFragmetAdapter(childFragmentManager,mFragmetList);
    }




    public List<Fragment> getViews() {
        return mFragmetList;
    }

//       f1.openDelstatus(b);

    public BookPageFragmetAdapter getBookPageFragmentAdatper() {
        return mBookPageFragmentAdatper;
    }

    private class BookPageFragmetAdapter extends FragmentPagerAdapter {
        private ArrayList<Fragment> inFragment;
        public BookPageFragmetAdapter(FragmentManager fm, ArrayList<Fragment> fragmetList) {
            super(fm);
            inFragment = fragmetList;
        }

        @Override
        public Fragment getItem(int i) {
            return inFragment.get(i);
        }

        @Override
        public int getCount() {
            return inFragment.size();
        }
    }


}
