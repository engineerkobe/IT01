package com.bignerdranch.android.demo2;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;

import com.bignerdranch.android.R;

public class Demo2 extends Fragment {
    private RecyclerView mDemoRecyclerView;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.book_article_main,container,false);
        mDemoRecyclerView = (RecyclerView) v.findViewById(R.id.book_talk_main_recyclerview);
        mDemoRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        mDemoRecyclerView.setAdapter(new DemoBookAdapter());
        return v;

    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        inflater.inflate(R.menu.main_home_toolbar,menu);
    }

    private class DemoBookAdapter extends RecyclerView.Adapter<DemoBookHolder> {

        @NonNull
        @Override
        public DemoBookHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
            LayoutInflater layoutInflater = LayoutInflater.from(getContext());
            return new DemoBookHolder(layoutInflater,viewGroup);
        }

        @Override
        public void onBindViewHolder(@NonNull DemoBookHolder demoBookHolder, int i) {

        }

        @Override
        public int getItemCount() {
            return 10;
        }
    }
    private class DemoBookHolder extends RecyclerView.ViewHolder {

        public DemoBookHolder(LayoutInflater layoutInflater, ViewGroup viewGroup) {
            super(layoutInflater.inflate(R.layout.book_article_main_item, viewGroup,false));
        }
    }
}
