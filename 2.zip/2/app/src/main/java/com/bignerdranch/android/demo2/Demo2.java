package com.bignerdranch.android.demo2;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.bignerdranch.android.R;
import com.bignerdranch.android.config.MyServer;
import com.bignerdranch.android.util.Internet;
import com.bignerdranch.android.util.JSONObjectToBean;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

public class Demo2 extends Fragment {
    private RecyclerView mArticleRecyclerView;
    private FloatingActionButton mPostButton;
    private List<Article> mArticleList;
    private ArticleAdapter mArticleAdapter;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
        mArticleList = new ArrayList<>();
        new ArticleGetInternet().execute();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable final ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.book_article_main, container, false);
        mPostButton = (FloatingActionButton) v.findViewById(R.id.book_article_main_postbutton);

        mArticleRecyclerView = (RecyclerView) v.findViewById(R.id.book_talk_main_recyclerview);
        mArticleRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        mArticleRecyclerView.setAdapter(
        mArticleAdapter = new ArticleAdapter());
        mPostButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = PostArticleActivity.newInstance(getContext());
                startActivity(intent);
            }
        });
        return v;

    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        inflater.inflate(R.menu.main_home_toolbar, menu);
    }

    class ArticleAdapter extends RecyclerView.Adapter<ArticleHolder> {

        @NonNull
        @Override
        public ArticleHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
            LayoutInflater layoutInflater = LayoutInflater.from(getContext());
            return new ArticleHolder(layoutInflater, viewGroup);
        }

        @Override
        public void onBindViewHolder(@NonNull ArticleHolder articleHolder, int i) {
            articleHolder.bind(mArticleList.get(i));
        }

        @Override
        public int getItemCount() {
            return mArticleList.size();
        }
    }

    class ArticleHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        private TextView mPosterTextView;
        private TextView mTitleTextView;
        private TextView mContentTextView;
        private Article mArticle;

        public ArticleHolder(LayoutInflater layoutInflater, ViewGroup viewGroup) {
            super(layoutInflater.inflate(R.layout.book_article_main_item, viewGroup, false));
            mPosterTextView = (TextView)itemView.findViewById(R.id.book_article_main_item_poster_textview);
            mTitleTextView = (TextView)itemView.findViewById(R.id.book_article_main_item_title_textview);
            mContentTextView = (TextView)itemView.findViewById(R.id.book_article_main_item_content_textview);
        }

        public void bind(Article article) {
            mArticle = article;
            mPosterTextView.setText(article.getPoster());
            mTitleTextView.setText(article.getTitle());
            mContentTextView.setText(article.getContent());
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            Intent intent = ArticleActivity.newIntent(getContext(),mArticle);
            startActivity(intent);
        }
    }

    private class ArticleGetInternet extends AsyncTask<String, Void, String> {
        private Context mContent;

        @Override
        protected String doInBackground(String... strings) {
            try {
                JSONArray jsonArray = new JSONArray(Internet.getUrlString( MyServer.GET_ARTICLE_LIST_URL));
                for (int i=0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                    mArticleList.add(JSONObjectToBean.JSONObjectToArticle(jsonObject));
                }
                return "";
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            } catch (ParseException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(String s) {
            mArticleAdapter.notifyDataSetChanged();
        }
    }
}
