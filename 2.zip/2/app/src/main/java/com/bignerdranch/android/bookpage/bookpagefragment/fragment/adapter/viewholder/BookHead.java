package com.bignerdranch.android.bookpage.bookpagefragment.fragment.adapter.viewholder;

import android.support.annotation.NonNull;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.bignerdranch.android.R;
import com.bignerdranch.android.bean.Book;

import java.util.ArrayList;

public class BookHead extends RecyclerView.ViewHolder {
    private final Book mBook;
    private TextView mTitle;
    //書的圖片顯示
    private ViewPager mImageViewPager;
    //頁數顯示
    private TextView mImageViewPagerCount;
    private ArrayList<View> mImageArrayList;

    public BookHead(LayoutInflater layoutInflater, ViewGroup viewGroup, Book book) {
        super(layoutInflater.inflate(R.layout.book_page_info_item_head, viewGroup, false));
        mBook = book;
//            (itemView);
        mImageViewPager = itemView.findViewById(R.id.book_page_info_viewpager);
        mImageViewPagerCount = itemView.findViewById(R.id.book_page_info_viewpager_count);
        mTitle = (TextView) itemView.findViewById(R.id.book_page_info_title);

        mImageArrayList = new ArrayList<>();
        for (int i = 0; i < 10; i++)
            mImageArrayList.add(new ImageFragment(layoutInflater.inflate(R.layout.image_fill, null)).create());
    }

    public void bind() {
        mTitle.setText(mBook.getName());
        init();
    }

    private void init() {
//                fragments.add(new ImageFragment());
        mImageViewPagerCount.setText(String.format("%s/%s 張",1,mImageArrayList.size()));
        ViewPagerAdapter adapter = new ViewPagerAdapter(mImageArrayList);
        mImageViewPager.setAdapter(adapter);
        /*
            頁數顯示
         */
        mImageViewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int i, float v, int i1) {

            }

            @Override
            public void onPageSelected(int i) {
                mImageViewPagerCount.setText(String.format("%s/%s 張",i+1,mImageArrayList.size()));
            }

            @Override
            public void onPageScrollStateChanged(int i) {

            }
        });
        adapter.notifyDataSetChanged();
    }

    //書訊息圖片
    private class ViewPagerAdapter extends PagerAdapter {
        private ArrayList<View> mFragmentList;

        public ViewPagerAdapter(ArrayList<View> image) {
            super();
            mFragmentList = image;
        }

        @NonNull
        @Override
        public Object instantiateItem(@NonNull ViewGroup container, int position) {
//                return super.instantiateItem(container, position);
            container.addView(mFragmentList.get(position));
            return mFragmentList.get(position);
        }

        @Override
        public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
//                super.destroyItem(container, position, object);
            container.removeView(mFragmentList.get(position));
        }

        @Override
        public int getCount() {
            return mFragmentList.size();
        }

        @Override
        public boolean isViewFromObject(@NonNull View view, @NonNull Object o) {
            return view == ((View)o);
        }
    }
}