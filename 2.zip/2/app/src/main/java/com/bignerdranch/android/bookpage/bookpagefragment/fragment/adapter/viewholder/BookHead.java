package com.bignerdranch.android.bookpage.bookpagefragment.fragment.adapter.viewholder;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.support.annotation.NonNull;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.RecyclerView;
import android.util.LruCache;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.bignerdranch.android.R;
import com.bignerdranch.android.config.MyServer;
import com.bignerdranch.android.demo.bean.Book;
import com.bignerdranch.android.util.DensityUtil;
import com.bignerdranch.android.util.Internet;

import java.io.IOException;
import java.util.ArrayList;

public class BookHead extends RecyclerView.ViewHolder {
    private final TextView mBookRFIDTextView;
    private final TextView mBookCaseTextView;
    private ViewGroup mViewGroup;
    private Context mContext;
    private LayoutInflater mLayoutInflater;
    private Book mBook;
    private TextView mTitle;
    //書的圖片顯示
    private ViewPager mImageViewPager;
    //頁數顯示
    private TextView mImageViewPagerCount;
    private ArrayList<View> mImageViewArrayList;
    private LruCache<String,Bitmap>mLruCache;
    private ViewPagerAdapter mImageViewAdapter;

    public BookHead(LayoutInflater layoutInflater, ViewGroup viewGroup, Book book, Context context) {
        super(layoutInflater.inflate(R.layout.book_page_info_item_head, viewGroup, false));
        mBook = book;
        mLruCache = new LruCache<>(10*1024*1024);
        mContext = context;
        mViewGroup = viewGroup;
//            (itemView);
        mImageViewPager =(ViewPager) itemView.findViewById(R.id.book_page_info_viewpager);
        mImageViewPagerCount = itemView.findViewById(R.id.book_page_info_viewpager_count);
        mTitle = (TextView) itemView.findViewById(R.id.book_page_info_title);
        mBookCaseTextView = (TextView) itemView.findViewById(R.id.book_page_info_bookcase);
        mBookRFIDTextView= (TextView) itemView.findViewById(R.id.book_page_info_rfid);

        mImageViewArrayList = new ArrayList<>();
        mLayoutInflater = layoutInflater;
        new DownloadImage().execute(String.format(MyServer.GET_BOOK_IMAGE_URL,book.getISBN()));

//        for (int i = 0; i < 10; i++)
//            mImageViewArrayList.add(new ImageFragment(layoutInflater.inflate(R.layout.book_page_fragment_container,null)).create());
    }

    public void bind() {
        mTitle.setText(mBook.getName());
        init();
    }

    private void init() {
        if(mBook.getRFID() != null) {
            mBookCaseTextView.setText(mBook.getRFID());
            mBookRFIDTextView.setText(mBook.getRFID());
        }
        mImageViewPagerCount.setText(String.format("%s/%s 張",1, mImageViewArrayList.size()));
        mImageViewAdapter = new ViewPagerAdapter(mImageViewArrayList);
        mImageViewPager.setAdapter(mImageViewAdapter);
        /*
            頁數顯示
         */
        mImageViewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int i, float v, int i1) {

            }

            @Override
            public void onPageSelected(int i) {

                mImageViewPagerCount.setText(String.format("%s/%s 張",i+1, mImageViewArrayList.size()));
            }

            @Override
            public void onPageScrollStateChanged(int i) {

            }
        });
    }

    //書訊息圖片
    private class ViewPagerAdapter extends PagerAdapter {

        private ArrayList<View> mFragmentList;

        public ViewPagerAdapter(ArrayList<View> image) {
            super();
            mFragmentList = image;
        }

        @NonNull
        @Override
        public Object instantiateItem(@NonNull ViewGroup container, int position) {
//                return super.instantiateItem(container, position);
            container.addView(mFragmentList.get(position));
            return mFragmentList.get(position);
        }

        @Override
        public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
//                super.destroyItem(container, position, object);
            container.removeView(mFragmentList.get(position));
        }

        @Override
        public int getCount() {
            return mFragmentList.size();
        }

        @Override
        public boolean isViewFromObject(@NonNull View view, @NonNull Object o) {
            return view == ((View)o);
        }

    }

    class DownloadImage extends AsyncTask<String, Void,Bitmap> {

        @Override
        protected Bitmap doInBackground(String... strings) {
            String url = strings[0];
            Bitmap bitmap = mLruCache.get(url);
            if(bitmap == null) {
                try {
                    byte[] bytes = Internet.getUrlBytes(url);
                    bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                    mLruCache.put(url,bitmap);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            return bitmap;
        }

        @Override
        protected void onPostExecute(Bitmap bitmap) {
//            Matrix matrix = new Matrix();
//            int h = mImageViewPager.getHeight()- DensityUtil.dip2px(mContext,50);

//            int w = mImageViewPager.getWidth();
//            int height = bitmap.getHeight();
//            int width = bitmap.getWidth();
//            float scaleWidth = ((float) w/width);
//            float scaleHeight = ((float) h/height);
//            matrix.postScale(scaleWidth,scaleHeight);
//            bitmap = Bitmap.createBitmap(bitmap,0,0,width,height,matrix,true) ;
            Drawable drawable = new BitmapDrawable(mContext.getResources(),bitmap);
            View view = mLayoutInflater.inflate(R.layout.book_page_fragment_container,mViewGroup,false);
            view.setBackground(drawable);
            mImageViewArrayList.add(view);
            mImageViewAdapter.notifyDataSetChanged();
            mImageViewPagerCount.setText(String.format("%s/%s 張",1, mImageViewArrayList.size()));

        }
    } // DownloadImage
}
