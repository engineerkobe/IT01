package com.bignerdranch.android;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;

import com.bignerdranch.android.bean.RFID;
import com.bignerdranch.android.bookpage.BookPageFragment;
import com.bignerdranch.android.bean.Book;

import java.util.Date;

public class BookPageActivity extends SingleNFCFragmentActivity {

    private static final String EXTRAS_BOOK_ISBN = "com.bignerdranch.android.bookintent.book_isbn";
    private static final String EXTRAS_BOOK_RFID = "com.bignerdranch.android.bookintent.book_rfid";
    private static final String EXTRAS_BOOK_DATE = "com.bignerdranch.android.bookintent.book_date";

    public static Intent newInstance(Context context, Book book, RFID rfid, Date date) {
        Intent intent =new Intent(context, BookPageActivity.class) ;
        intent.putExtra(EXTRAS_BOOK_ISBN,book);
        intent.putExtra(EXTRAS_BOOK_RFID,rfid);
        intent.putExtra(EXTRAS_BOOK_DATE,date);
        return intent;
    }

    public static Date getServerDate(Intent intent) {
        return (Date) intent.getSerializableExtra(EXTRAS_BOOK_DATE);
    }
    public static Book getBook(Intent intent) {
        return (Book)intent.getSerializableExtra(EXTRAS_BOOK_ISBN);
    }

    public static RFID getRFID(Intent intent) {
        return (RFID) intent.getSerializableExtra(EXTRAS_BOOK_RFID);
    }
    @Override
    protected Fragment createFragment() {
        //關閉案兩次退出
        super.setOneMoreTimeExit(false);
        return BookPageFragment.newInstance();
    }

}
