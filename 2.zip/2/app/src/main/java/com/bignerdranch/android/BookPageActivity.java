package com.bignerdranch.android;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;

import com.bignerdranch.android.bean.Book;
import com.bignerdranch.android.bookpage.BookPageFragment;

public class BookPageActivity extends SingleFragmentActivity{

    public static final String EXTRAS_BOOK_ISBN = "com.bignerdranch.android.bookintent.book_isbn";

    public static Intent newInstance(Context context, Book book) {
        Intent intent =new Intent(context, BookPageActivity.class) ;
        intent.putExtra(EXTRAS_BOOK_ISBN,book.getISBN());
        return intent;
    }
    @Override
    protected Fragment createFragment() {
        //關閉案兩次退出
        super.setOneMoreTimeExit(false);
        return BookPageFragment.newInstance();
    }

}
