package com.bignerdranch.android.bookpage;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.bignerdranch.android.BookPageActivity;
import com.bignerdranch.android.R;
import com.bignerdranch.android.bean.Book;
import com.bignerdranch.android.bean.RFID;
import com.bignerdranch.android.bookpage.bookpagefragment.BookPagerFragmetntLab;

import java.util.ArrayList;

public class BookPageFragment extends Fragment {


    private ViewPager mViewPager;
    private TabLayout mTabLayout;
    private ArrayList<Fragment> fragments = new ArrayList<>();

//    private String[] mTabTitles = new String[]{"最新","热门","我的"};
    private int [] mTabTitles = {R.string.introduction,R.string.location_message};
    private BookPagerFragmetntLab mBookPagerFragmetntLab;
    private Book mBook;
    private RFID mRFID;
    private Button mBorrowButton;
    private static final String EXTRAS_BOOK_ISBN = "com.bignerdranch.android.bookintent.book_isbn";
    private static final String EXTRAS_BOOK_RFID = "com.bignerdranch.android.bookintent.book_rfid";

    public static BookPageFragment newInstance() {
        Bundle args = new Bundle();
        BookPageFragment bookPageFragment =new BookPageFragment();
        bookPageFragment.setArguments(args);
        return new BookPageFragment();
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent intent = getActivity().getIntent();
        mBook = BookPageActivity.getBook(intent);
        mRFID = BookPageActivity.getRFID(intent);
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.book_page_status_bar, container, false);

        mViewPager = (ViewPager) v.findViewById(R.id.book_page_viewpager);
        mTabLayout = (TabLayout) v.findViewById(R.id.book_page_tablayout);
        //設置title
        for(int tmp: mTabTitles)
            mTabLayout.addTab((mTabLayout.newTab()).setText(tmp));

        mViewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(mTabLayout));
        mTabLayout.addOnTabSelectedListener(new TabLayout.ViewPagerOnTabSelectedListener(mViewPager));
        BookPagerFragmetntLab bookPagerFragmetntLab = new BookPagerFragmetntLab(getChildFragmentManager(),mBook,mRFID);
        mViewPager.setOffscreenPageLimit(2);
        mViewPager.setAdapter(bookPagerFragmetntLab.getBookPageFragmentAdatper());
        mBorrowButton = (Button) v.findViewById(R.id.book_page_info_fragment_button);
        return v;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        // TODO: Use the ViewModel
    }

}
