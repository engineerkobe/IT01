package com.bignerdranch.android.demo2;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.bignerdranch.android.R;
import com.bignerdranch.android.config.MyUser;
import com.bignerdranch.android.util.Internet;

import java.io.IOException;

public class PostArticleFragment extends Fragment {
    private TextView postButton;
    private EditText mContentEditText;
    private EditText mTitleEditText;

    public static PostArticleFragment newInstance() {
        PostArticleFragment fragment = new PostArticleFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.book_article_post, container, false);
        postButton = (TextView) v.findViewById(R.id.book_article_post_toolbar_postbutton);
        mTitleEditText = (EditText)v.findViewById(R.id.book_article_post_title_edittext);
        mContentEditText = (EditText)v.findViewById(R.id.book_article_post_content_edittext);
        postButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new PostTask(getContext(), MyUser.getAccount(),mTitleEditText.getText().toString(),mContentEditText.getText().toString()).execute();
                getActivity().finish();
            }
        });
        return v;
    }

    class PostTask extends AsyncTask<String,Void,String > {
        String mAccount ;
        String mTitle;
        String mContent;
        Context mContext;

        public PostTask(Context context ,String account, String title, String content) {
            mAccount = account;
            mTitle = title;
            mContent = content;
            mContext = context;
        }

        @Override
        protected void onPostExecute(String s) {
            Toast.makeText(mContext,s,Toast.LENGTH_SHORT).show();
        }

        @Override
        protected String doInBackground(String... strings) {
            try {
                return  Internet.postArticle(mContext,mAccount,mTitle,mContent);
            } catch (IOException e) {
                e.printStackTrace();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            return null;
        }
    }
}
