package com.bignerdranch.android.demo2;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.bignerdranch.android.R;
import com.bignerdranch.android.config.MyServer;
import com.bignerdranch.android.config.MyUser;
import com.bignerdranch.android.util.Internet;
import com.bignerdranch.android.util.JSONObjectToBean;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

public class ArticleFragment extends Fragment {
    private RecyclerView mArticleRecyclerView;
    private ArticleAdapter mArticleAdapter;
    private List<Article> mArticleList;
    private Button mPostArticleButton;
    private EditText mPostArticleEditText;
    private static final int POSTER = 0;
    private static final int SIMLE_POSTER = 1;
    private Article mArticle;
    private String rootid;

    public static ArticleFragment newInstance() {
        Bundle args = new Bundle();
        ArticleFragment fragment = new ArticleFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        rootid = ArticleActivity.getRootid(getActivity().getIntent());
        mArticleList = new ArrayList<>();
        new ArticleGetInternet().execute();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.article_main, container, false);
        mArticleRecyclerView = (RecyclerView) v.findViewById(R.id.article_main_recyclerview);
        mPostArticleButton = (Button) v.findViewById(R.id.article_main_small_button);
        mPostArticleEditText = (EditText) v.findViewById(R.id.article_main_small_edittext);

        mArticleRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        mArticleAdapter = new ArticleAdapter(inflater);
        mArticleRecyclerView.setAdapter(mArticleAdapter);
        mArticleRecyclerView.addItemDecoration(new MyDecorationOne());

        mPostArticleButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new PostTask(getContext(), MyUser.getAccount(),null,mPostArticleEditText.getText().toString(),String.valueOf(mArticle.getRootid())).execute();
            }
        });

        return v;
    }

    public class MyDecorationOne extends RecyclerView.ItemDecoration {

        /**
         * 画线
         */
            @Override
            public void onDraw(@NonNull Canvas c, @NonNull RecyclerView parent, @NonNull RecyclerView.State state) {
                super.onDraw(c,parent,state);
                int count = parent.getChildCount();
                for(int i =0 ; i <count-1; i++) {
                   View v = parent.getChildAt(i);
                   int top = v.getTop();
                   int bottom = v.getBottom();
                   Paint p = new Paint();
                   p.setColor(0xffb1b1b1);
                   c.drawRect(20,bottom,v.getWidth()-20,bottom+5,p);

                }
            }

        /**
         * 设置条目周边的偏移量
         */
            @Override
            public void onDrawOver(@NonNull Canvas c, @NonNull RecyclerView parent, @NonNull RecyclerView.State state) {
                super.onDrawOver(c, parent, state);
            }

            @Override
            public void getItemOffsets(@NonNull Rect outRect, @NonNull View view, @NonNull RecyclerView parent, @NonNull RecyclerView.State state) {
                super.getItemOffsets(outRect, view, parent, state);
                outRect.bottom = 5;
            }

    }


    private class ArticleAdapter extends RecyclerView.Adapter<ArticleHolder> {

        private final LayoutInflater mInflater;

        public ArticleAdapter(LayoutInflater inflater) {
            mInflater = inflater;
        }

        @Override
        public int getItemViewType(int position) {
            return position;
        }

        @NonNull
        @Override
        public ArticleHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
            switch (i) {
                case POSTER:
                    return new ArticleHolder(mInflater,viewGroup,R.layout.book_article_main_item);
                default:
                    return new ArticleHolder(mInflater,viewGroup,R.layout.book_article_main_item);

            }
        }

        @Override
        public void onBindViewHolder(@NonNull ArticleHolder articleHolder, int i) {
            switch (i) {
                case POSTER:
                    articleHolder.bind(mArticleList.get(i));
                break;
                default:
                    articleHolder.bind2(mArticleList.get(i));
                break;
            }
        }

        @Override
        public int getItemCount() {
            return mArticleList.size();
        }
    }
    private class  ArticleHolder extends RecyclerView.ViewHolder {
        private TextView mPosterTextView;
        private TextView mTitleTextView;
        private TextView mContentTextView;
        private Article mArticle;

        public ArticleHolder(@NonNull LayoutInflater inflater, ViewGroup viewGroup, int layout) {
            super(inflater.inflate(layout,viewGroup,false));
            switch (layout) {
                case R.layout.book_article_main_item:
                    mPosterTextView = (TextView)itemView.findViewById(R.id.book_article_main_item_poster_textview);
                    mTitleTextView = (TextView)itemView.findViewById(R.id.book_article_main_item_title_textview);
                    mContentTextView = (TextView)itemView.findViewById(R.id.book_article_main_item_content_textview);
                    break;
                case R.layout.article_main_small_poster_item:
            }
        }

        void bind(Article article) {
            mArticle = article;
            mPosterTextView.setTextSize(25);
            mPosterTextView.setText(article.getPoster());
            mTitleTextView.setText(article.getTitle());
            mContentTextView.setText(article.getContent());
        }

        public void bind2(Article article) {
            mTitleTextView.setVisibility(View.GONE);
            mArticle = article;
            mPosterTextView.setText(article.getPoster());
            mTitleTextView.setText(article.getTitle());
            mContentTextView.setText(article.getContent());
        }


    }

    private class ArticleGetInternet extends AsyncTask<String, Void, String> {
        private Context mContent;

        @Override
        protected String doInBackground(String... strings) {
            try {
                JSONArray jsonArray = new JSONArray(Internet.getUrlString( String.format(MyServer.GET_ARTICLE_LIST_ROOTID_URL,rootid)));
//                JSONArray jsonArray = new JSONArray(Internet.getUrlString( String.format(MyServer.GET_ARTICLE_LIST_ROOTID_URL,"1")));
                mArticleList.clear();
                for (int i=0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                    mArticleList.add(JSONObjectToBean.JSONObjectToArticle(jsonObject));
                }
                return "";
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            } catch (ParseException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(String s) {
            mArticleAdapter.notifyDataSetChanged();
            if(mArticleList.get(0)!= null)
                mArticle = mArticleList.get(0);
        }
    }
      class PostTask extends AsyncTask<String,Void,String > {
        private String mRootId;
        String mAccount ;
        String mTitle;
        String mContent;
        Context mContext;

        public PostTask(Context context ,String account, String title, String content,String rootid) {
            mAccount = account;
            mTitle = title;
            mContent = content;
            mContext = context;
            mRootId = rootid;
        }

        @Override
        protected void onPostExecute(String s) {
            Toast.makeText(mContext,s,Toast.LENGTH_SHORT).show();
            new ArticleGetInternet().execute();
        }

        @Override
        protected String doInBackground(String... strings) {
            try {
                return  Internet.postArticle(mContext,mAccount,mTitle,mContent,mRootId);
            } catch (IOException e) {
                e.printStackTrace();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            return null;
        }
    }
}
