package com.bignerdranch.android;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.view.KeyEvent;
import android.widget.Toast;


public abstract class SingleFragmentActivity extends AppCompatActivity {

    private long mExitTime;
    private boolean isOneMoreTimeExit;
    private ConnectivityManager mConnectivityManager;

    protected abstract Fragment createFragment();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.book_page_fragment_container);
        FragmentManager fragmentManager = getSupportFragmentManager();
        Fragment fragment = fragmentManager.findFragmentById(R.id.book_page_fragment_container);
        //檢查網路連線
        mConnectivityManager = (ConnectivityManager)  getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = mConnectivityManager.getActiveNetworkInfo();

//        if(networkInfo.isConnected() ){
        //network == null 代表沒有網路
        if(networkInfo != null ){

            if(fragment == null) {
                fragment = createFragment();
                fragmentManager
                        .beginTransaction()
                        .add(R.id.book_page_fragment_container, fragment)
                        .commit();
            }
        }else
        {
            //查看是否有網路
            Dialog alertDialog = new AlertDialog.Builder(this).
                    setTitle(R.string.internet_error).
                    setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    SingleFragmentActivity.this.finish();
                                }
                            }
                    ).create();
            alertDialog.show();
        }

    }
    //是否開啟在案一次退出
    void setOneMoreTimeExit(boolean oneMoreTimeExit) {
        isOneMoreTimeExit = oneMoreTimeExit;
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        // TODO Auto-generated method stub
        if(isOneMoreTimeExit)
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if ((System.currentTimeMillis() - mExitTime) > 2000) {// 如果两次按键时间间隔大于2000毫秒，则不退出
                Toast.makeText(this, "再按一次退出程序", Toast.LENGTH_SHORT).show();
                mExitTime = System.currentTimeMillis();// 更新mExitTime
            } else {
                System.exit(0);// 否则退出程序
            }
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }
}
