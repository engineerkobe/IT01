package com.bignerdranch.android.bookpage.bookpagefragment.fragment;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.bignerdranch.android.BookPageActivity;
import com.bignerdranch.android.R;
import com.bignerdranch.android.bean.Book;
import com.bignerdranch.android.bean.RFID;
import com.bignerdranch.android.bookpage.bookpagefragment.fragment.adapter.BookPageInfoAdapter;
import com.bignerdranch.android.bookpage.bookpagefragment.fragment.adapter.BookPageInfoItemDecoration;
import com.bignerdranch.android.config.MyServer;
import com.bignerdranch.android.config.MyUser;
import com.bignerdranch.android.login.UserLab;
import com.bignerdranch.android.util.Internet;

import java.io.IOException;
import java.util.Date;

public class BookPageInfo extends Fragment {
    private static final String FM = "FragmentManager";
    private RecyclerView mRecyclerView;
    private Book mBook;
    private RFID mRFID;
    private Context mConText;
    private Button mBorrowButton;
    private Date mDate;

    public static BookPageInfo newInstance(Book book, RFID RFID) {
        Bundle args = new Bundle();
        BookPageInfo fragment = new BookPageInfo();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent intent = getActivity().getIntent();
        mBook = BookPageActivity.getBook(intent);
        mRFID = BookPageActivity.getRFID(intent);
        mDate = BookPageActivity.getServerDate(intent);
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.book_page_info_fragment, container, false);
        mConText = getContext();
        mRecyclerView = (RecyclerView)v.findViewById(R.id.book_page_info_fragment_recyclerview);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        mRecyclerView.addItemDecoration(new BookPageInfoItemDecoration());
        mRecyclerView.setAdapter(new BookPageInfoAdapter(inflater,container,getChildFragmentManager(),mBook,mRFID,mConText));
        mBorrowButton = (Button) v.findViewById(R.id.book_page_info_fragment_button);
        initBorrowButton();
        return v;
    }

    private void initBorrowButton() {
        mBorrowButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final MyUser user = UserLab.get(getContext()).getUser();
                if(user == null || mRFID == null) {
                    Toast.makeText(getContext(), "請先登入或者用RFID掃過", Toast.LENGTH_SHORT).show();
                }else {
                    new AlertDialog.Builder(getContext())
                            .setTitle("確定要借書")
                            .setMessage("確定要借書")
                            .setNegativeButton("no",null)
                            .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    new BorrowBookTask(MyUser.getAccount(),mRFID.getRfid()).execute();
//                                    Toast.makeText(getContext(), "借書成功", Toast.LENGTH_SHORT).show();
                                }
                            })
                            .show();
                }
            }
        });
    }
    private class BorrowBookTask extends AsyncTask<Void,Void,String> {
        private String mAccount;
        private String mRfid;

        public BorrowBookTask(String account, String rfid) {
            mAccount = account;
            mRfid = rfid;
        }

        @Override
        protected String doInBackground(Void... voids) {
            String arg = String.format("account=%s&rfid=%s&time=%s",mAccount,mRfid,mDate.getTime());
            try {
                return Internet.postUrl(MyServer.BORROWBOOK_URL,arg);
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(String s) {
            Toast.makeText(getContext(), s, Toast.LENGTH_SHORT).show();
        }
    }

}
