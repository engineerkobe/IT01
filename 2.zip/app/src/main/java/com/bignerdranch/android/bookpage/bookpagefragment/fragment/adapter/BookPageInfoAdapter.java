package com.bignerdranch.android.bookpage.bookpagefragment.fragment.adapter;

import android.content.Context;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.v4.app.FragmentManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.bignerdranch.android.R;
import com.bignerdranch.android.bean.Book;
import com.bignerdranch.android.bean.RFID;
import com.bignerdranch.android.bookpage.bookpagefragment.fragment.viewholder.BookHead;


/*
    書籍介紹頁面
    頭
    身體
    底部

 */
public class BookPageInfoAdapter extends RecyclerView.Adapter {
    private final static String TAG = "BookPageInfoAdapter";
    private final LayoutInflater mLayoutInflater;
    private final ViewGroup mViewGroup;
    private final FragmentManager mFragmentManger;
    private final Book mBook;
    private final Context mContext;
    private final RFID mRFID;

    private static final class ItemType {
        static final int head = 0;
        static final int body = 1;
        static final int qualityassurance1 = 2;
        static final int qualityassurance2 = 3;
        static final int bottom1 = 4;
        static final int bottom2 = 5;
    }

    @Override
    public int getItemViewType(int position) {
//        Log.i(TAG,String.valueOf(position));

        return position;
    }

    public BookPageInfoAdapter(LayoutInflater inflater, ViewGroup viewGroup, FragmentManager childFragmentManager, Book book, RFID RFID, Context context) {
        mLayoutInflater = inflater;
        mViewGroup = viewGroup;
        mFragmentManger = childFragmentManager;
        mBook = book;
        mRFID = RFID;
        mContext = context;
    }
    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        switch (i) {
            case ItemType.head:
                return new BookHead(mLayoutInflater,viewGroup,mBook,mRFID,mContext);
            case ItemType.body:
                return new BookBody(mLayoutInflater,viewGroup);
            case ItemType.qualityassurance1:
                return new BookBody(mLayoutInflater.inflate(R.layout.book_page_info_item_quality_assurance,mViewGroup,false));
            case ItemType.qualityassurance2:
                return new BookBody(mLayoutInflater.inflate(R.layout.book_page_info_item_quality_assurance,mViewGroup,false));
            case ItemType.bottom1:
                return new BookBody(mLayoutInflater.inflate(R.layout.book_page_info_item_bottom,mViewGroup,false));
            case ItemType.bottom2:
                return new BookBody(mLayoutInflater.inflate(R.layout.book_page_info_item_bottom,mViewGroup,false));
        }
        return null;
    }

    @RequiresApi(api = Build.VERSION_CODES.P)
    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
        switch (i) {
            case 0: {
                BookHead headHolder = (BookHead) viewHolder;
                headHolder.bind();
                break;
            }
            case  1:
                BookBody bodyHolder = (BookBody) viewHolder;
                bodyHolder.bind();
                break;

        }
    }

    @Override
    public int getItemCount() {
        return 2;
    }



    private class BookBody extends RecyclerView.ViewHolder {
        private TextView mContent;
        private TextView mShowAllContent;
        private int linecount;
        public BookBody(LayoutInflater layoutInflater, ViewGroup viewGroup) {
            super(layoutInflater.inflate(R.layout.book_page_info_item_body,viewGroup,false));
            mContent = (TextView) itemView.findViewById(R.id.book_page_info_body_content);
            mShowAllContent = (TextView) itemView.findViewById(R.id.book_page_info_body_content_visibility);

        }

        public BookBody(View inflate) {
            super(inflate);
        }
        @RequiresApi(api = Build.VERSION_CODES.P)
        private void bind() {
            mShowAllContent.setText("典籍查看更多詳情");
            mContent.setMaxLines(8);
                mContent.setText(mBook.getContent());
            mContent.post(new Runnable() {
                @Override
                /*
                計算行數 決定要不要展開
                 */
                public void run() {
                    Log.i(TAG,"有幾行"+(linecount=mContent.getLayout().getLineCount()));
                    if(linecount >= 8) {
                        mShowAllContent.setVisibility(View.VISIBLE);
                    }
                    else
                        mShowAllContent.setVisibility(View.GONE);
                }
            });


            mShowAllContent.setOnClickListener(new View.OnClickListener() {
                boolean showall = false;
                @Override
                public void onClick(View view) {
                    if(showall =!showall) {
                        mShowAllContent.setText("收起");
                        mContent.setMaxLines(Integer.MAX_VALUE);
                    }else {
                        mContent.setMaxLines(8);
                        mShowAllContent.setText("典籍查看更多詳情");
                    }
                }
            });
        }
    }


    private class BookBottom extends RecyclerView.ViewHolder {
        public BookBottom(@NonNull View itemView) {
            super(itemView);
        }
    }
}
